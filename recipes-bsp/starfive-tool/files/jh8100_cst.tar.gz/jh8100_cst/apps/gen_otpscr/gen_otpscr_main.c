/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file gen_otpscr_main.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <debug_utils.h>
#include <crypto_utils.h>
#include <parse_utils.h>
#include <global.h>
#include <otp_map.h>
#include <crc32.h>
#include <app_common.h>

static struct image_conf g_conf;

static const char * INTEREST_CONFS[] = {
//	CONF_IMAGE_BIN,
//	CONF_IMAGE_FLAGS,
//	CONF_IMAGE_ENTRYPOINT_L,
//	CONF_IMAGE_ENTRYPOINT_H,
//	CONF_IMAGE_VERSION,
//	CONF_OTP_NV_COUNTER_OFF,
	CONF_OTP_IMG_AES_KEY_IDX,
	CONF_OTP_PUBKEY_TABLE_IDX,
	CONF_EC_PRI_KEY_0,
	CONF_EC_PRI_KEY_1,
	CONF_EC_PRI_KEY_2,
	CONF_EC_PRI_KEY_3,
	CONF_EC_PRI_KEY_4,
	CONF_EC_PRI_KEY_5,
	CONF_EC_PRI_KEY_6,
	CONF_EC_PRI_KEY_7,
	CONF_EC_KEY_SEL,
//	CONF_EC_PARAM_P,
//	CONF_EC_PARAM_A,
//	CONF_EC_PARAM_B,
//	CONF_EC_PARAM_GX,
//	CONF_EC_PARAM_GY,
//	CONF_EC_PARAM_N,
//	CONF_EC_SIGN_KINV,
//	CONF_EC_SIGN_RP,
	CONF_AES_KEY,
//	CONF_AES_IV,
//	CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME,
//	CONF_OUTPUT_IMAGE_HDR_FILENAME,
//	CONF_OUTPUT_IMAGE_HASH_FILENAME,
//	CONF_OUTPUT_IMAGE_SIG_FILENAME,
	CONF_OUTPUT_OTPSCR_FILENAME,
};

static void print_usage(const char *exec)
{
	printf("\nUsage: %s [options] <input_file>\n", exec);
	printf(" --help              Display this summary\n");
	printf(" --out file          save otp script details into file\n");
	printf(" input_file          config file defines all information\n");
	printf("\n");
}

static int parse_args(int argc, char **argv)
{
	enum {
		OPTION_start = 1000,
		OPTION_out         ,
	};

	static struct option long_options[] = 
	{
		/* These options set a flag. */
		//{"verbose", no_argument,       &verbose_flag, 1},
		{"out"       , required_argument, 0, OPTION_out },
		{"help"      , no_argument      , 0, 'h'},
		{0, 0, 0, 0}
	};

	while (1)
	{
		/* getopt_long stores the option index here. */
		int option_index = 0;

		int c = getopt_long (argc, argv, "u:", long_options, &option_index);

		/* Detect the end of the options. */
		if (c == -1)
			break;

		switch (c)
		{
		case 0:
			/* If this option set a flag, do nothing else now. */
			if (long_options[option_index].flag != 0)
			break;
			//printf ("option %s", long_options[option_index].name);
			//if (optarg)
			//    printf (" with arg %s", optarg);
			//printf ("\n");
			break;

		case OPTION_out:
			parser_read_s(optarg, &g_conf.output_otpscr_filename, sizeof(g_conf.output_otpscr_filename));
			g_conf.has_output_otpscr_filename = 1;
			break;

		case 'h':
			print_usage(argv[0]);
			exit(0);
			break;

		case '?':
			/* getopt_long already printed an error message. */
			break;

		default:
			abort ();
		}
		//printf ("option --%s with value `%s'\n", long_options[option_index].name, optarg);
	}
	return 0;
}

static int fprint_otp_words(FILE *fp, const void *p, uint32_t len, uint32_t otp_addr)
{
	int i;

	//unaligned
	if ((len & 3) || (otp_addr & 3))
		return -EINVAL;

	if (len > 4)
		dump_bytes_line(fp, p, len, NULL);
	fprintf(fp, "Addr, Value\n");
	fprintf(fp, "-----------------------\n");
	const uint32_t *pw = (uint32_t *)p;
	for (i = 0; i < len; i += 4, pw++)
		fprintf(fp, "0x%04x, 0x%08x\n", otp_addr + i, *pw);
	fprintf(fp, "\n");

	return 0;
}

static int output_aes_key(FILE *fp, int key_idx, const void *key, int len)
{
	const uint32_t AES_KEY_ADDRS[] = {
		OTP1_BASE+OTP1_Kfw_0, OTP1_BASE+OTP1_Kfw_1, OTP1_BASE+OTP1_Kfw_2,
	};
	if (key_idx >= ARRAY_SIZE(AES_KEY_ADDRS)) {
		fprintf(stderr, "invalid key_idx %d\n", key_idx);
		return -EINVAL;
	}
	uint32_t addr = AES_KEY_ADDRS[key_idx];
	fprintf(fp, "AES256 CBC Key #%d:\n", key_idx);
	fprint_otp_words(fp, key, len, addr);
	return 0;
}

static int output_pukt_hash(FILE *fp, int pukt_idx, const void *pukt, int len)
{
	const uint32_t PUKT_HASH_ADDRS[] = {
		OTP2_BASE+OTP2_HASHPUK_0, OTP2_BASE+OTP2_HASHPUK_1, OTP2_BASE+OTP2_HASHPUK_2,
	};
	uint8_t pukt_hash[SHA256_HASH_LEN] = {0};
	if (pukt_idx >= ARRAY_SIZE(PUKT_HASH_ADDRS)) {
		fprintf(stderr, "invalid pukt_idx %d\n", pukt_idx);
		return -EINVAL;
	}

	if (sha256_buf(pukt, len, pukt_hash, SHA256_HASH_LEN)) {
		fprintf(stderr, "sha256 fail\n");
		return -EINVAL;
	}

	fprintf(fp, "PUKT #%d:\n", pukt_idx);
	dump_xxd(fp, "", 4, pukt, len, 1);
	fprintf(fp, "HASHPUK #%d:\n", pukt_idx);
	uint32_t addr = PUKT_HASH_ADDRS[pukt_idx];
	fprint_otp_words(fp, pukt_hash, sizeof(pukt_hash), addr);
	return 0;
}

static int handle_otpscr(void)
{
	FILE *fp = fopen(g_conf.output_otpscr_filename, "w") ?: stdout;
	int ret = 1;
	uint32_t addr, value;

	// AES256 key
	if (g_conf.has_otp_img_aes_key_idx) {
		if (output_aes_key(fp, g_conf.otp_img_aes_key_idx, g_conf.aes_key, sizeof(g_conf.aes_key)))
			goto EXIT;
	}

	// PUK table hash
	if (g_conf.ec_key_count) {
		uint32_t pukt_len = g_conf.ec_key_count * sizeof(struct ec_pubkey);
		if (output_pukt_hash(fp, g_conf.otp_pubkey_table_idx, g_conf.ec_pubkeys, pukt_len))
			goto EXIT;
	}

	// SECURE_BOOT
	addr = OTP1_BASE + OTP1_SECURE_BOOT;
	value = SECURE_BOOT_EN;
	fprintf(fp, "SECURE_BOOT:\n");
	fprint_otp_words(fp, &value, sizeof(value), addr);

	ret = 0;

EXIT:
	if (fp != stdout)
		fclose(fp);

	return ret;
}

int main(int argc, char **argv)
{
	printf("\n\n--------------------------------------------------------\n");
	printf("StarFive Generate OTP Scripts Tool, version %s%s.\n", VERSION, DEBUG ? "(DEBUG)" : "");
	
	if (argc < 2) {
		print_usage(argv[0]);
		return 0;
	}
	parse_args(argc, argv);
	
	//parse input file
	if (app_load_conf(argv[argc - 1], &g_conf, INTEREST_CONFS, ARRAY_SIZE(INTEREST_CONFS))) {
		printf("parse input file failed\n");
		return 1;
	}
	app_print_conf(&g_conf);
	
	if (handle_otpscr()) {
		printf("handle_otpscr() error\n");
		return 1;
	}
	
	return 0;
}
