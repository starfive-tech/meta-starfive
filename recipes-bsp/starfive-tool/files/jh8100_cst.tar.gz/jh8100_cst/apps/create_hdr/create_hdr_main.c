/**
 ******************************************************************************
 * @copyright Copyright (c) 2020 StarFive Technology Co.,Ltd.
 * 
 * @file create_hdr_main.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <debug_utils.h>
#include <crypto_utils.h>
#include <parse_utils.h>
#include <global.h>
#include <app_common.h>
#include <crc32.h>

static struct image_conf g_conf;

static const char * INTEREST_CONFS[] = {
	CONF_IMAGE_BIN,
	CONF_IMAGE_FLAGS,
	CONF_IMAGE_ENTRYPOINT_L,
	CONF_IMAGE_ENTRYPOINT_H,
	CONF_IMAGE_VERSION,
	CONF_OTP_NV_COUNTER_OFF,
	CONF_OTP_IMG_AES_KEY_IDX,
	CONF_OTP_PUBKEY_TABLE_IDX,
	CONF_EC_PRI_KEY_0,
	CONF_EC_PRI_KEY_1,
	CONF_EC_PRI_KEY_2,
	CONF_EC_PRI_KEY_3,
	CONF_EC_PRI_KEY_4,
	CONF_EC_PRI_KEY_5,
	CONF_EC_PRI_KEY_6,
	CONF_EC_PRI_KEY_7,
	CONF_EC_KEY_SEL,
	CONF_EC_PARAM_P,
	CONF_EC_PARAM_A,
	CONF_EC_PARAM_B,
	CONF_EC_PARAM_GX,
	CONF_EC_PARAM_GY,
	CONF_EC_PARAM_N,
//	CONF_EC_SIGN_KINV,
//	CONF_EC_SIGN_RP,
	CONF_AES_KEY,
	CONF_AES_IV,
	CONF_AES_KEK,
	CONF_AES_DEK,
//	CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME,
	CONF_OUTPUT_IMAGE_HDR_FILENAME,
	CONF_OUTPUT_IMAGE_HASH_FILENAME,
//	CONF_OUTPUT_IMAGE_SIG_FILENAME,
//	CONF_OUTPUT_OTPSCR_FILENAME,
	CONF_KEYS_REVOCATION,
};

static void print_usage(const char *exec)
{
    printf("\nUsage: %s [options] <input_file>\n", exec);
    printf(" --help                      Display this summary\n");
    printf(" --bin infile                Input IMAGE .bin file, without any header,\n");
    printf("                             will override the config from input_file.\n");
    printf(" --version val               version of infile (0<=val<129)\n");
    printf("                             will override the config from input_file.\n");
    printf(" --hdr file                  to save IMAGE header.\n");
    printf(" --hash file                 to save IMAGE sha256 hash (IMAGE header + IMAGE bin).\n");
    printf(" input_file                  config file defines all information\n");
    printf("\n");
    //printf();
}

static int parse_args(int argc, char **argv)
{
    enum {
        OPTION_start = 1000     ,
        OPTION_bin              ,
        OPTION_version       ,
        OPTION_hdr              ,
        OPTION_hash             ,
    };

    static struct option long_options[] = 
    {
        /* These options set a flag. */
        //{"verbose", no_argument,       &verbose_flag, 1},
        {"bin"              , required_argument, 0, OPTION_bin              },
        {"version"          , required_argument, 0, OPTION_version          },
        {"hdr"              , required_argument, 0, OPTION_hdr              },
        {"hash"             , required_argument, 0, OPTION_hash             },

        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    while (1)
    {
        /* getopt_long stores the option index here. */
        int option_index = 0;

        int c = getopt_long (argc, argv, "", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1)
            break;

        switch (c)
        {
        case 0:
            /* If this option set a flag, do nothing else now. */
            if (long_options[option_index].flag != 0)
                break;
            //printf ("option %s", long_options[option_index].name);
            //if (optarg)
            //    printf (" with arg %s", optarg);
            //printf ("\n");
            break;

        case OPTION_bin:
            parser_read_s(optarg, g_conf.image_bin, sizeof(g_conf.image_bin));
            g_conf.has_image_bin = 1;
            break;

        case OPTION_version:
            parser_read_w_le(optarg, &g_conf.image_version, sizeof(g_conf.image_version));
            g_conf.has_image_version = 1;
            break;

        case OPTION_hdr:
            parser_read_s(optarg, g_conf.output_image_hdr_filename, sizeof(g_conf.output_image_hdr_filename));
            g_conf.has_output_image_hdr_filename = 1;
            break;

        case OPTION_hash:
            parser_read_s(optarg, g_conf.output_image_hash_filename, sizeof(g_conf.output_image_hash_filename));
            g_conf.has_output_image_hash_filename = 1;
            break;

        case 'h':
            print_usage(argv[0]);
            exit(0);
            break;

        case '?':
            /* getopt_long already printed an error message. */
            break;

        default:
            abort ();
        }
        //printf ("option --%s with value `%s'\n", long_options[option_index].name, optarg);
    }
    return 0;
}

static int handle_image_hdr(void)
{
	char *buf = NULL;
	int buf_size = 0, offset = 0, pubkey_tbl_off = 0, pubkey_tbl_size = 0, sign_off = 0, img_off = 0;
	const int ALIGNMENT = 16;
	int i;

	// calc the offset of sections
	offset = ALIGN(sizeof(struct image_hdr), ALIGNMENT);
	buf_size = offset;
	if (g_conf.ec_key_count) {
		pubkey_tbl_off = offset;
		pubkey_tbl_size = g_conf.ec_key_count * sizeof(struct ec_pubkey);
		offset += pubkey_tbl_size;
		buf_size = offset; //renew buf_size to include the pubkey table for secure boot image
		sign_off = offset;
		offset += sizeof(struct ecdsa_sig);
	}
	img_off = offset;

	buf = (char*)malloc(buf_size);
	if (!buf) {
		fprintf(stderr, "failed to malloc buf for hdr file\n");
		return 1;
	}
	memset(buf, 0, buf_size);

	struct image_hdr *hdr = (struct image_hdr *)buf;
	if (app_gen_image_hdr(&g_conf, hdr)) {
		fprintf(stderr, "failed to generate image_hdr\n");
		return 1;
	}
	hdr->ec_pubkey_table_off = pubkey_tbl_off;
	if (hdr->ec_pubkey_table_off == 0)
		hdr->ec_pubkey_count = hdr->ec_pubkey_select = 0;
	hdr->sign_off = sign_off;
	if (hdr->sign_off == 0)
		hdr->sign_len = 0;
	hdr->img_off = img_off;

	//copy pubkey table
	if (hdr->ec_pubkey_count) {
		memcpy(buf + hdr->ec_pubkey_table_off, g_conf.ec_pubkeys, pubkey_tbl_size);
	
		struct ec_pubkey *puk = (struct ec_pubkey *)(buf + hdr->ec_pubkey_table_off);
		for (i = 0; i < hdr->ec_pubkey_count; i++, puk++) {
			printf("puk %d:\n", i);
			printf("  x: ");
			dump_bytes_line(stdout, puk->x, sizeof(puk->x), NULL);
			printf("  y: ");
			dump_bytes_line(stdout, puk->y, sizeof(puk->y), NULL);
			//disable reverse to keep all big-number big-endian
			////reverse word order for ccore_crypto (BigEndian: 1), make sure least significant word goes first
			//reverse_w_be2le(puk->x, ARRAY_SIZE(puk->x));
			//reverse_w_be2le(puk->y, ARRAY_SIZE(puk->y));
		}
	}

	//disable reverse to keep all big-number big-endian
	////reverse word order for ccore_crypto (BigEndian: 1), make sure least significant word goes first
	//reverse_w_be2le(hdr->ec_params.p , ARRAY_SIZE(hdr->ec_params.p ));
	//reverse_w_be2le(hdr->ec_params.a , ARRAY_SIZE(hdr->ec_params.a ));
	//reverse_w_be2le(hdr->ec_params.b , ARRAY_SIZE(hdr->ec_params.b ));
	//reverse_w_be2le(hdr->ec_params.gx, ARRAY_SIZE(hdr->ec_params.gx));
	//reverse_w_be2le(hdr->ec_params.gy, ARRAY_SIZE(hdr->ec_params.gy));
	//reverse_w_be2le(hdr->ec_params.n , ARRAY_SIZE(hdr->ec_params.n ));

	if (g_conf.has_output_image_hdr_filename && savefile(g_conf.output_image_hdr_filename, buf, buf_size))
		return -EIO;
	
	debug_printf("pubkey_tbl_off = 0x%x (%d/%d)\n", hdr->ec_pubkey_table_off, hdr->ec_pubkey_select, hdr->ec_pubkey_count);
	debug_printf("sign_off = 0x%x\n", hdr->sign_off);
	debug_printf("img_off = 0x%x, img_crc = 0x%x\n", hdr->img_off, hdr->img_crc32);
	debug_dump(stdout, buf, buf_size);

	if (g_conf.has_output_image_hash_filename) {
		uint8_t hash[SHA256_HASH_LEN] = {0};
		if (app_gen_image_hash(&g_conf, hdr, hash, sizeof(hash))) {
			fprintf(stderr, "failed to generate image hash\n");
			return 1;
		}
		if (g_conf.has_output_image_hash_filename
			&& savefile(g_conf.output_image_hash_filename, hash, SHA256_HASH_LEN)) {
			return -EIO;
		}
	}

	return 0;
}

int main(int argc, char **argv)
{
    printf("\n\n--------------------------------------------------------\n");
    printf("StarFive Create Header Tool, version %s%s.\n", VERSION, DEBUG ? "(DEBUG)" : "");

    if (argc < 2) {
        print_usage(argv[0]);
        return 0;
    }
    parse_args(argc, argv);

    //parse input file
    if (app_load_conf(argv[argc - 1], &g_conf, INTEREST_CONFS, ARRAY_SIZE(INTEREST_CONFS))) {
        printf("parse input file failed\n");
        return 1;
    }
    app_print_conf(&g_conf);

    if (handle_image_hdr()) {
        printf("handle_image_hdr() error\n");
        return 1;
    }

    return 0;
}
