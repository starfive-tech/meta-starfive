/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file gen_sign_main.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <debug_utils.h>
#include <crypto_utils.h>
#include <parse_utils.h>
#include <global.h>
#include <app_common.h>
#include <crc32.h>

static struct image_conf g_conf;

static const char * INTEREST_CONFS[] = {
//	CONF_IMAGE_BIN,
//	CONF_IMAGE_FLAGS,
//	CONF_IMAGE_ENTRYPOINT_L,
//	CONF_IMAGE_ENTRYPOINT_H,
//	CONF_IMAGE_VERSION,
//	CONF_OTP_NV_COUNTER_OFF,
//	CONF_OTP_IMG_AES_KEY_IDX,
//	CONF_OTP_PUBKEY_TABLE_IDX,
	CONF_EC_PRI_KEY_0,
	CONF_EC_PRI_KEY_1,
	CONF_EC_PRI_KEY_2,
	CONF_EC_PRI_KEY_3,
	CONF_EC_PRI_KEY_4,
	CONF_EC_PRI_KEY_5,
	CONF_EC_PRI_KEY_6,
	CONF_EC_PRI_KEY_7,
	CONF_EC_KEY_SEL,
	CONF_EC_PARAM_P,
	CONF_EC_PARAM_A,
	CONF_EC_PARAM_B,
	CONF_EC_PARAM_GX,
	CONF_EC_PARAM_GY,
	CONF_EC_PARAM_N,
	CONF_EC_SIGN_KINV,
	CONF_EC_SIGN_RP,
//	CONF_AES_KEY,
//	CONF_AES_IV,
//	CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME,
//	CONF_OUTPUT_IMAGE_HDR_FILENAME,
	CONF_OUTPUT_IMAGE_HASH_FILENAME,
	CONF_OUTPUT_IMAGE_SIG_FILENAME,
//	CONF_OUTPUT_OTPSCR_FILENAME,
};

static void print_usage(const char *exec)
{
    printf("\nUsage: %s [options] <input_file>\n", exec);
    printf(" --help          Display this summary\n");
    printf(" --hash file     binary file contain 256 bits sha256 hash\n");
    printf(" --sig file      output file for signature\n");
    printf(" input_file      config file defines all information\n");
    printf("\n");
    //printf();
}

static int parse_args(int argc, char **argv)
{
    enum {
        OPTION_start = 1000,
        OPTION_hash        ,
        OPTION_sig         ,
    };

    static struct option long_options[] = 
    {
        /* These options set a flag. */
        //{"verbose", no_argument,       &verbose_flag, 1},
        {"hash", required_argument, 0, OPTION_hash},
        {"sig" , required_argument, 0, OPTION_sig },

        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    while (1)
    {
        /* getopt_long stores the option index here. */
        int option_index = 0;

        int c = getopt_long (argc, argv, "", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1)
            break;

        switch (c)
        {
        case 0:
            /* If this option set a flag, do nothing else now. */
            if (long_options[option_index].flag != 0)
                break;
            //printf ("option %s", long_options[option_index].name);
            //if (optarg)
            //    printf (" with arg %s", optarg);
            //printf ("\n");
            break;

        case OPTION_hash:
            parser_read_s(optarg, g_conf.output_image_hash_filename, sizeof(g_conf.output_image_hash_filename));
            g_conf.has_output_image_hash_filename = 1;
            break;

        case OPTION_sig:
            parser_read_s(optarg, g_conf.output_image_sig_filename, sizeof(g_conf.output_image_sig_filename));
            g_conf.has_output_image_sig_filename = 1;
            break;

        case 'h':
            print_usage(argv[0]);
            exit(0);
            break;

        case '?':
            /* getopt_long already printed an error message. */
            break;

        default:
            abort ();
        }
        //printf ("option --%s with value `%s'\n", long_options[option_index].name, optarg);
    }
    return 0;
}

static int handle_image_sig(void)
{
    struct ecdsa_sig sig = {0};
    uint8_t image_hash[SHA256_HASH_LEN] = {0};

    if (!g_conf.has_ec_key_sel ||
        app_validate_ec_key(&g_conf, g_conf.ec_key_sel)) {
            fprintf(stderr, "no ec private key invalid\n");
            return -EINVAL;
    }

    if (!g_conf.has_output_image_hash_filename) {
        fprintf(stderr, "image hash file not set\n");
        return 1;
    }
    if (sizeof(image_hash) != filesize(g_conf.output_image_hash_filename)) {
        fprintf(stderr, "wrong image hash file size\n");
        return 1;
    }
    loadfile(g_conf.output_image_hash_filename, image_hash);

    if (g_conf.has_ec_sign_kinv && g_conf.has_ec_sign_rp) {
        if (ecdsa256_sign_ex(ec_loadkey(g_conf.ec_pri_keys[g_conf.ec_key_sel]),
            g_conf.ec_sign_kinv, g_conf.ec_sign_rp,
            image_hash, sizeof(image_hash), (uint8_t*)(&sig), sizeof(sig))) {
            fprintf(stderr, "failed to generate signature\n");
            return -EINVAL;
        }
    } else {
        if (ecdsa256_sign(ec_loadkey(g_conf.ec_pri_keys[g_conf.ec_key_sel]),
            image_hash, sizeof(image_hash), (uint8_t*)(&sig), sizeof(sig))) {
            fprintf(stderr, "failed to generate signature\n");
            return -EINVAL;
        }
    }

    if (g_conf.has_output_image_sig_filename) {
        struct ecdsa_sig sig_rev = {0};

        memcpy(&sig_rev, &sig, sizeof(sig));

	//disable reverse to keep all big-number big-endian
	////reverse word order for ccore_crypto (BigEndian: 1), make sure least significant word goes first
	//reverse_w_be2le(sig_rev.r, ARRAY_SIZE(sig_rev.r));
	//reverse_w_be2le(sig_rev.s, ARRAY_SIZE(sig_rev.s));
        if (savefile(g_conf.output_image_sig_filename, &sig_rev, sizeof(sig_rev))) {
            return -EIO;
        }
    }

    return 0;
}

int main(int argc, char **argv)
{
    printf("\n\n--------------------------------------------------------\n");
    printf("StarFive Generate Signature Tool, version %s%s.\n", VERSION, DEBUG ? "(DEBUG)" : "");

    if (argc < 2) {
        print_usage(argv[0]);
        return 0;
    }
    parse_args(argc, argv);

    //parse input file
    if (app_load_conf(argv[argc - 1], &g_conf, INTEREST_CONFS, ARRAY_SIZE(INTEREST_CONFS))) {
        printf("parse input file failed\n");
        return 1;
    }
    app_print_conf(&g_conf);

    if (handle_image_sig()) {
        printf("handle_image_sig() error\n");
        return 1;
    }

    return 0;
}
