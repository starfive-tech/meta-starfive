/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file gen_ciphers_main.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <getopt.h>
#include <debug_utils.h>
#include <crypto_utils.h>
#include <parse_utils.h>
#include <global.h>
#include <app_common.h>
#include <crc32.h>

static struct image_conf g_conf;

static const char * INTEREST_CONFS[] = {
	CONF_IMAGE_BIN,
	CONF_IMAGE_FLAGS,
//	CONF_IMAGE_ENTRYPOINT_L,
//	CONF_IMAGE_ENTRYPOINT_H,
//	CONF_IMAGE_VERSION,
//	CONF_OTP_NV_COUNTER_OFF,
//	CONF_OTP_IMG_AES_KEY_IDX,
//	CONF_OTP_PUBKEY_TABLE_IDX,
//	CONF_EC_PRI_KEY_0,
//	CONF_EC_PRI_KEY_1,
//	CONF_EC_PRI_KEY_2,
//	CONF_EC_PRI_KEY_3,
//	CONF_EC_PRI_KEY_4,
//	CONF_EC_PRI_KEY_5,
//	CONF_EC_PRI_KEY_6,
//	CONF_EC_PRI_KEY_7,
//	CONF_EC_KEY_SEL,
//	CONF_EC_PARAM_P,
//	CONF_EC_PARAM_A,
//	CONF_EC_PARAM_B,
//	CONF_EC_PARAM_GX,
//	CONF_EC_PARAM_GY,
//	CONF_EC_PARAM_N,
//	CONF_EC_SIGN_KINV,
//	CONF_EC_SIGN_RP,
	CONF_AES_KEY,
	CONF_AES_IV,
	CONF_AES_KEK,
	CONF_AES_DEK,
	CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME,
//	CONF_OUTPUT_IMAGE_HDR_FILENAME,
//	CONF_OUTPUT_IMAGE_HASH_FILENAME,
//	CONF_OUTPUT_IMAGE_SIG_FILENAME,
//	CONF_OUTPUT_OTPSCR_FILENAME,
};

static void print_usage(const char *exec)
{
    printf("\nUsage: %s [options] <input_file>\n", exec);
    printf(" --help                 Display this summary\n");
    printf(" --bin infile           Input SBL .bin file, without any header,\n");
    printf("                        will override the config from input_file.\n");
//    printf(" --aes_iv               file to save AES256-CBC-IV.\n");
    printf(" --bin_cipher           file to save bin cipher for later use.\n");
    printf(" input_file             config file defines all information\n");
    printf("\n");
    //printf();
}

static int parse_args(int argc, char **argv)
{
    enum {
        OPTION_start = 1000     ,
        OPTION_bin              ,
//        OPTION_aes_iv           ,
        OPTION_bin_cipher       ,
    };

    static struct option long_options[] = 
    {
        /* These options set a flag. */
        //{"verbose", no_argument,       &verbose_flag, 1},
        {"bin"              , required_argument, 0, OPTION_bin              },
//        {"aes_iv"           , required_argument, 0, OPTION_aes_iv           },
        {"bin_cipher"       , required_argument, 0, OPTION_bin_cipher       },

        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    while (1)
    {
        /* getopt_long stores the option index here. */
        int option_index = 0;

        int c = getopt_long (argc, argv, "", long_options, &option_index);

        /* Detect the end of the options. */
        if (c == -1)
            break;

        switch (c)
        {
        case 0:
            /* If this option set a flag, do nothing else now. */
            if (long_options[option_index].flag != 0)
                break;
            //printf ("option %s", long_options[option_index].name);
            //if (optarg)
            //    printf (" with arg %s", optarg);
            //printf ("\n");
            break;

        case OPTION_bin:
            parser_read_s(optarg, g_conf.image_bin, sizeof(g_conf.image_bin));
            g_conf.has_image_bin = 1;
            break;

//        case OPTION_aes_iv:
//            parser_read_s(optarg, g_conf.output_aes_iv_filename, sizeof(g_conf.output_aes_iv_filename));
//            g_conf.has_output_aes_iv_filename = 1;
//            break;

        case OPTION_bin_cipher:
            parser_read_s(optarg, g_conf.output_image_bin_cipher_filename, sizeof(g_conf.output_image_bin_cipher_filename));
            g_conf.has_output_image_bin_cipher_filename = 1;
            break;

        case 'h':
            print_usage(argv[0]);
            exit(0);
            break;

        case '?':
            /* getopt_long already printed an error message. */
            break;

        default:
            abort ();
        }
        //printf ("option --%s with value `%s'\n", long_options[option_index].name, optarg);
    }
    return 0;
}

static int handle_aes_key_iv(void)
{
    if (!g_conf.has_aes_iv_file) {
        printf("generate aes iv:\n");
        crypto_rand_bytes((uint8_t*)g_conf.aes_iv, sizeof(g_conf.aes_iv));
        dump_bytes_line(stdout, g_conf.aes_iv, sizeof(g_conf.aes_iv), NULL);
    }

    //NOTE: prince has been removed from 8100
    //encode aes key with crypto prince
//    prince_encode_aes256_key(g_conf.aes_key, g_conf.princed_aes_key);

//    if (g_conf.has_output_aes_iv_filename) {
//        if (savefile(g_conf.output_aes_iv_filename, g_conf.aes_iv, sizeof(g_conf.aes_iv))) {
//            return -EIO;
//        }
//    }

    return 0;
}

static int handle_bin_cipher(void)
{
	if (!g_conf.has_output_image_bin_cipher_filename) {
		return 0;
	}

	int cipher_len = 0;
	printf("encrypt %s\n", g_conf.image_bin);
	if (g_conf.image_flags & BIF_IS_ENCRYPTED) {
		cipher_len = aes256_cbc_crypt_file(1, (uint8_t*)g_conf.aes_dek, (uint8_t*)g_conf.aes_iv,
			g_conf.image_bin, g_conf.output_image_bin_cipher_filename);
		
#if (DEBUG == 1)
		char decrypt_file[MAX_PATH_LEN] = "";
		sprintf(decrypt_file, "%s.dec", g_conf.output_image_bin_cipher_filename);
		aes256_cbc_crypt_file(0, (uint8_t*)g_conf.aes_dek, (uint8_t*)g_conf.aes_iv,
			g_conf.output_image_bin_cipher_filename, decrypt_file);
#endif
	} else {
		cipher_len = copyfile(g_conf.output_image_bin_cipher_filename, g_conf.image_bin);
	}
	if (cipher_len <= 0) {
		fprintf(stderr, "failed to do aes256 cbc encrypt\n");
		return 1;
	}
	return 0;
}

int main(int argc, char **argv)
{
    printf("\n\n--------------------------------------------------------\n");
    printf("StarFive Generate Ciphers Tool, version %s%s.\n", VERSION, DEBUG ? "(DEBUG)" : "");

    if (argc < 2) {
        print_usage(argv[0]);
        return 0;
    }
    parse_args(argc, argv);

    //parse input file
    if (app_load_conf(argv[argc - 1], &g_conf, INTEREST_CONFS, ARRAY_SIZE(INTEREST_CONFS))) {
        printf("parse input file failed\n");
        return 1;
    }
    app_print_conf(&g_conf);

    if (handle_aes_key_iv()) {
        printf("handle_aes_key_iv() error\n");
        return 1;
    }

    if (handle_bin_cipher()) {
        printf("handle_bin_cipher() error\n");
        return 1;
    }

    return 0;
}