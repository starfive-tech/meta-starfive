# JH8100 signing tool, for SCP Bootloader Normal and Secure boot.

## Requirements
* openssl

## Compile
* debug version (for R&D only, contains confidential contents)
make DEBUG=1

* release version
make

## Usage
cd <dir_of_jh8100_cst>

* normal boot
./mkbif.sh bin [version]
find output file: <bin>.normal.out

* secure boot
./mkbif_secure.sh bin [version]
find output file: <bin>.secure.out
