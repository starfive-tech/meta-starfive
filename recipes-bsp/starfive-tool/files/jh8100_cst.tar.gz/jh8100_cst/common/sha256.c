/**
 ******************************************************************************
 * @copyright Copyright (c) 2020 StarFive Technology Co.,Ltd.
 * 
 * @file sha256.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sha.h>
#include <openssl/sha.h>

static SHA256_CTX s_sha256;

int sha256_init(void)
{
    return !SHA256_Init(&s_sha256);
}

int sha256_update(const uint8_t *buf, size_t len)
{
    return !SHA256_Update(&s_sha256, buf, len);
}

int sha256_update_file(const char *path)
{
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        return -EIO;
    }

    const uint32_t BUF_SIZE = 1024;
    uint8_t buf[BUF_SIZE];
    size_t rd_len = 0; 
    while ((rd_len = fread(buf, 1, BUF_SIZE, fp)) > 0) {
        if (!SHA256_Update(&s_sha256, buf, rd_len)) {
            fclose(fp);
            return 1;
        }
    }
    fclose(fp);
    return 0;
}

int sha256_final(uint8_t *hash, size_t hash_len)
{
    return !SHA256_Final(hash, &s_sha256);
}

int sha256_buf(const uint8_t *buf, size_t len, uint8_t *hash, size_t hash_len)
{
    //SHA256_CTX sha256; //use static global one instead
    SHA256_Init(&s_sha256);
    SHA256_Update(&s_sha256, buf, len);
    return !SHA256_Final(hash, &s_sha256);
}

int sha256_file(const char *path, uint8_t *hash, size_t hash_len)
{
    FILE *fp = fopen(path, "rb");
    long file_len = 0;
    if (!fp) {
        return -EIO;
    }
    fseek(fp, 0, SEEK_END);
    file_len = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (file_len == 0) {
        fclose(fp);
        return -EINVAL;
    }

    const uint32_t BUF_SIZE = 1024;
    uint8_t buf[BUF_SIZE];
    size_t rd_len = 0; 
    //SHA256_CTX sha256; //use static global one instead
    SHA256_Init(&s_sha256);
    while ((rd_len = fread(buf, 1, BUF_SIZE, fp)) > 0) {
        SHA256_Update(&s_sha256, buf, rd_len);
    }
    fclose(fp);
    return !SHA256_Final(hash, &s_sha256);
}
