/**
 ******************************************************************************
 * @copyright Copyright (c) 2020 StarFive Technology Co.,Ltd.
 * 
 * @file ec256.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <openssl/ecdsa.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <global.h>
#include <debug_utils.h>

void *ec_loadkey(const char *key_path)
{
    FILE *fp = NULL;
    EC_KEY *ec_key = NULL;
    
    fp = fopen(key_path, "rb");
    if (!fp) {
        return NULL;
    }
    ec_key = PEM_read_ECPrivateKey(fp, &ec_key, NULL, NULL);
    if (!ec_key) {
        fclose(fp);
        return NULL;
    }
//    printf("load key: %s\n", key_path);
    EC_KEY_set_group(ec_key, EC_GROUP_new_by_curve_name(NID_X9_62_prime256v1));
    fclose(fp);

#if DEBUG
    //private key shall be kept secret, only print in debug version
    const BIGNUM* d = EC_KEY_get0_private_key(ec_key);
    int d_len = BN_num_bytes(d);
    printf("d: %s, %d bytes\n", BN_bn2hex(d), d_len);
    uint8_t d_bin[32] = {0};
    BN_bn2bin(d, d_bin);
    dump_words_line(stdout, d_bin, d_len, ",", 0);
#endif

    return ec_key;
}

int ec_pubkey2bin(void *key, uint8_t *bin, int bin_len)
{
    int ret = 1;
    EC_KEY *ec_key = (EC_KEY *)key;
    //const BIGNUM* d = EC_KEY_get0_private_key(ec_key);
    const EC_POINT* Q = EC_KEY_get0_public_key(ec_key);
    const EC_GROUP* group = EC_KEY_get0_group(ec_key);
    BIGNUM* x = BN_new();
    BIGNUM* y = BN_new();
    //BIGNUM* z = BN_new();

    //if (!EC_POINT_get_Jprojective_coordinates_GFp(group, Q, x, y, z, NULL))
    if (!EC_POINT_get_affine_coordinates_GFp(group, Q, x, y, NULL)) {
        goto EXIT;
    }

    int x_len = BN_num_bytes(x);
    BN_bn2bin(x, bin);
    BN_bn2bin(y, bin+x_len);

#if DEBUG
    int y_len = BN_num_bytes(y);
    //printf("d: %s\n", BN_bn2hex(d));
    printf("Qx: %s, %d bytes\n", BN_bn2hex(x), x_len);
    //dump_words_line(stdout, bin, x_len, ",", 0);
    printf("Qy: %s, %d bytes\n", BN_bn2hex(y), y_len);
    //dump_words_line(stdout, bin+x_len, y_len, ",", 0);
    //printf("Z: %s\n", BN_bn2hex(z));
#endif

    ret = 0;

EXIT:
    BN_free(x);
    BN_free(y);
    return ret;
}

int ecdsa256_sign_ex(
        void *key, //key loaded by ec256_load_key()
        const void *kinv_bin,
        const void *rp_bin,
        const uint8_t *hash,
        int hash_len,
        uint8_t *sig,
        int sig_len
    )
{
    EC_KEY *ec_key = (EC_KEY *)key;
    BIGNUM *kinv = NULL, *rp = NULL;

    if (!key || !hash || !sig || !sig_len) {
        ERROR_LOG("arguments contains null pointer\n");
        return -EINVAL;
    }

    if (!EC_KEY_can_sign(ec_key)) {
        ERROR_LOG("ec_key can't sign\n");
        return -EINVAL;
    }

    if (!kinv_bin || !rp_bin) {
        BN_CTX *ctx = BN_CTX_new();
        if (!ECDSA_sign_setup(ec_key, ctx, &kinv, &rp)) {
            BN_CTX_free(ctx);
            return -EINVAL;
        }
        BN_CTX_free(ctx);
        printf("generate random kinv & rp\n");
    } else {
        kinv = BN_new();
        rp = BN_new();
        BN_bin2bn((unsigned char *)kinv_bin, 32, kinv);
        BN_bin2bn((unsigned char *)rp_bin, 32, rp);
        printf("load kinv & rp from config\n");
    }
    printf("kinv: %s, %d bytes\n", BN_bn2hex(kinv), BN_num_bytes(kinv));
    printf("rp  : %s, %d bytes\n", BN_bn2hex(rp  ), BN_num_bytes(rp  ));

    ECDSA_SIG *ecdsa_sig = ECDSA_do_sign_ex(hash, hash_len, kinv, rp, ec_key);
    if (!ecdsa_sig) {
        printf("ecdsa sign failed.\n");
        return -EINVAL;
    }
    const BIGNUM *r = ECDSA_SIG_get0_r(ecdsa_sig);
    const BIGNUM *s = ECDSA_SIG_get0_s(ecdsa_sig);

    BN_bn2bin(r, sig);
    BN_bn2bin(s, sig+BN_num_bytes(r));

    printf("hash: ");
    dump_bytes_line(stdout, hash, hash_len, NULL);
    printf("r: %s, %d bytes\n", BN_bn2hex(r), BN_num_bytes(r));
    printf("s: %s, %d bytes\n", BN_bn2hex(s), BN_num_bytes(s));

    if (1 == ECDSA_do_verify(hash, hash_len, ecdsa_sig, ec_key)) {
        printf("ecdsa verify check PASS\n");
    } else {
        printf("ecdsa verify check FAIL\n");
        return -EINVAL;
    }

    if (kinv) BN_free(kinv);
    if (rp) BN_free(rp);

    return 0;
}

int ecdsa256_sign(
        void *key, //key loaded by ec256_load_key()
        const uint8_t *hash,
        int hash_len,
        uint8_t *sig,
        int sig_len
    )
{
    return ecdsa256_sign_ex(key, NULL, NULL, hash, hash_len, sig, sig_len);
}