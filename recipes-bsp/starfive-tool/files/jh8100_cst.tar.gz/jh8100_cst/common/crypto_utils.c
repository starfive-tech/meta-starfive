#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <openssl/x509v3.h>
#include <openssl/rand.h>
#include <global.h>
#include <crypto_utils.h>
#include <debug_utils.h>

int crypto_rand_bytes(uint8_t *buf, int num)
{
    return RAND_bytes(buf, num);
}

uint8_t *crypto_string_to_hex(const char *str, long *buflen)
{
    return string_to_hex(str, buflen);
}
