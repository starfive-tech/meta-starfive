/**
 ******************************************************************************
 * @copyright Copyright (c) 2020 StarFive Technology Co.,Ltd.
 * 
 * @file prince.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __TOOLS_PRINCE_H__
#define __TOOLS_PRINCE_H__

enum {
    PRINCE_ENC=0,
    PRINCE_DEC
};

uint64_t prince(uint64_t datai, const uint64_t *key, uint8_t decode);

/**
  * @brief  Encode aes256 key with prince secret, to generate real AES256 key used in sec.
  * @param  in 256 bits AES key, 8 Big Endian words.
  *         in[0]: b255~b224, ..., in[7]: b31~b0
  * @param  out 256 bits encrypted output, 8 Big Endian words.
  *         out[0]: b255~b224, ..., out[7]: b31~b0
  * @retval 0 for success, else for error.
  */
int prince_encode_aes256_key(const uint32_t *in, uint32_t *out);

/**
  * @brief  Encode dbg key with prince secret. to generate real dbg key used in sec.
  * @param  in 128 bits dbg key, 4 Big Endian words.
  *         in[0]: b127~b96, ..., in[3]: b31~b0
  * @param  out 128 bits encrypted output, 4 Big Endian words.
  *         out[0]: b127~b96, ..., out[3]: b31~b0
  * @param  uid chip unique id, the word burnt in otp addr 0.
  * @retval 0 for success, else for error.
  */
int prince_encode_dbg_key(const uint32_t *in, uint32_t *out, uint32_t uid);

#endif
