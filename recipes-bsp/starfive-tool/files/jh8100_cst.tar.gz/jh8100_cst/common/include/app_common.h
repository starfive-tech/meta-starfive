/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file app_common.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __TOOLS_APP_COMMON_H__
#define __TOOLS_APP_COMMON_H__

int app_load_conf(const char *input_file, struct image_conf *conf, const char *interest[], int interest_num);
void app_print_conf(const struct image_conf *conf);

int app_load_ec_params(const struct image_conf *conf, struct ec_params *ec_params);
int app_validate_ec_key(const struct image_conf *conf, int key_sel);

int app_gen_image_hdr(const struct image_conf *conf, struct image_hdr *hdr);
int app_gen_image_hash(const struct image_conf *conf, const struct image_hdr *hdr, uint8_t *hash, int hash_len);

#endif /* __TOOLS_APP_COMMON_H__ */
