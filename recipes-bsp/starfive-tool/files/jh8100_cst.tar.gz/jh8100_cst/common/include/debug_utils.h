#ifndef __DEBUG_UTILS_H__
#define __DEBUG_UTILS_H__

#include <stdio.h>
#include <stdint.h>

#if (DEBUG == 1)
#define debug_printf(fmt,...)       printf("[DEBUG]" fmt, ##__VA_ARGS__)
#define debug_dump                  dump
#define debug_dump_bytes_line       dump_bytes_line
#define debug_dump_words_line       dump_words_line
#else
#define debug_printf(...)
#define debug_dump(...)
#define debug_dump_bytes_line(...)
#define debug_dump_words_line(...)
#endif

#define ERROR_LOG(fmt,...)  printf("%s(), ln %d:" fmt, __FUNCTION__, __LINE__, ##__VA_ARGS__)

void dump(FILE *fp, const void *p, int n);
void dump_bytes_line(FILE *fp, const void *p, int n, char *sep);
void dump_words_line(FILE *fp, const void *p, int n, char *sep, int little_endian);
void dump_xxd(FILE *fp, const char *desc, int g, const void *p, int n, int little_endian);

#endif
