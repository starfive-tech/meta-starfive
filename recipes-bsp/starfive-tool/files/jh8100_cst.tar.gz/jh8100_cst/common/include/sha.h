/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file sha.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __TOOLS_SHA_H__
#define __TOOLS_SHA_H__

#include <stdio.h>
#include <stdint.h>

#define SHA256_HASH_LEN     32

int sha256_init(void);
int sha256_update(const uint8_t *buf, size_t len);
int sha256_update_file(const char *path);
int sha256_final(uint8_t *hash, size_t hash_len);

int sha256_buf(const uint8_t *buf, size_t len, uint8_t *hash, size_t hash_len);
int sha256_file(const char *path, uint8_t *hash, size_t hash_len);

#endif /* __TOOLS_SHA_H__ */
