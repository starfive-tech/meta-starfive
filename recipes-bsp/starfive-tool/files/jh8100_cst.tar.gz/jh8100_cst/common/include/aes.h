/**
 ******************************************************************************
 * @copyright Copyright (c) 2020 StarFive Technology Co.,Ltd.
 * 
 * @file aes.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __TOOLS_AES_H__
#define __TOOLS_AES_H__

#include <stdio.h>
#include <stdint.h>

int aes256_cbc_crypt(
        int encrypt,
        int pad,
        const uint8_t *key,
        const uint8_t *iv,
        uint8_t *in,
        int inlen,
        uint8_t *out,
        int outlen
    );

int aes256_cbc_crypt_file(
        int encrypt,
        const uint8_t *key,
        const uint8_t *iv,
        const char *infile,
        const char *outfile
    );

#endif
