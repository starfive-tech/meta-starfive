#ifndef __TOOLS_GLOBAL_H__
#define __TOOLS_GLOBAL_H__

typedef int8_t		s8;
typedef uint8_t		u8;
typedef int16_t		s16;
typedef uint16_t	u16;
typedef int32_t		s32;
typedef uint32_t	u32;
typedef int64_t		s64;
typedef uint64_t	u64;
typedef unsigned long	ulong;

#define MAX_PATH_LEN    1024

static inline uint32_t read32_le(const void *p)
{
	return  ((uint32_t)((uint8_t*)p)[0]<< 0)|
		((uint32_t)((uint8_t*)p)[1]<< 8)|
		((uint32_t)((uint8_t*)p)[2]<<16)|
		((uint32_t)((uint8_t*)p)[3]<<24);
}

static inline uint32_t read32_be(const void *p)
{
	return  ((uint32_t)((uint8_t*)p)[3]<< 0)|
		((uint32_t)((uint8_t*)p)[2]<< 8)|
		((uint32_t)((uint8_t*)p)[1]<<16)|
		((uint32_t)((uint8_t*)p)[0]<<24);
}


static inline uint64_t read64_le(const void *p)
{
	return  ((uint64_t)((uint8_t*)p)[0]<< 0)|
		((uint64_t)((uint8_t*)p)[1]<< 8)|
		((uint64_t)((uint8_t*)p)[2]<<16)|
		((uint64_t)((uint8_t*)p)[3]<<24)|
		((uint64_t)((uint8_t*)p)[4]<<32)|
		((uint64_t)((uint8_t*)p)[5]<<40)|
		((uint64_t)((uint8_t*)p)[6]<<48)|
		((uint64_t)((uint8_t*)p)[7]<<56);
}

static inline uint64_t read64_be(const void *p)
{
	return  ((uint64_t)((uint8_t*)p)[7]<< 0)|
		((uint64_t)((uint8_t*)p)[6]<< 8)|
		((uint64_t)((uint8_t*)p)[5]<<16)|
		((uint64_t)((uint8_t*)p)[4]<<24)|
		((uint64_t)((uint8_t*)p)[3]<<32)|
		((uint64_t)((uint8_t*)p)[2]<<40)|
		((uint64_t)((uint8_t*)p)[1]<<48)|
		((uint64_t)((uint8_t*)p)[0]<<56);
}

#ifndef offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(arry)    (sizeof(arry)/sizeof((arry)[0]))
#endif

#ifndef ALIGN
#define ALIGN(x,a)              __ALIGN_MASK((x),(typeof(x))(a)-1)
#define ALIGN_DOWN(x, a)        ALIGN((x) - ((a) - 1), (a))
#define __ALIGN_MASK(x,mask)    (((x)+(mask))&~(mask))
#endif

struct ec_params {
	u32 p[8];
	u32 a[8];
	u32 b[8];
	u32 gx[8];
	u32 gy[8];
	u32 n[8];
	u8 reserved[64];
};

struct ec_pubkey {
	u32 x[8];
	u32 y[8];
};

struct ecdsa_sig {
	u32 r[8];
	u32 s[8];
};

//BIF_V1
struct image_hdr {
	u32 magic_num;                  //0x0, Boot Image Header Magic Number. ("BIF\0"? 0x00464942)
#define BIF_MAGIC_NUM	0x00464942
	u32 bif_version;                //0x4, Boot Image Header Version
#define BIF_VERSION_1	1
	u32 entry_point_l;              //0x8, Low 32bits of where "Data" shall be loaded and excuted
	u32 entry_point_h;              //0xC, High 32bits of where "Data" shall be loaded and excuted
	u32 nv_counter[4];              //0x10, 128-bit Anti-Rollback Counter
#define BIF_NV_COUNTER_LEN     16
	u32 otp_nv_counter_off;         //0x20, Index of the Platform Non-Volatile (NV) Counter reside in Secure OTP
	u8 otp_img_aes_key_idx;         //0x24, Firmware AES encryption key index (Kfw_x)
	u8 otp_pubkey_table_idx;        //0x25, range 0~2, for ec_pubkey_table validation against HASH in Secure OTP
	u8 reserved0[2];                
	u32 ec_pubkey_table_off;        //0x28, Offset to "EC-256 Public Key"
	u8 ec_pubkey_count;             //0x2C, The number of ec_pubkeys in the table
#define BIF_MAX_EC_PUBKEY_NUM  8
	u8 ec_pubkey_select;            //0x2D, [0, ec_pubkey_count - 1]
	u8 reserved1[2];                
	u32 sign_off;                   //0x30, Offset to "Signature"
	u32 sign_len;                   //0x34, Length of "Signature"
	u32 img_off;                    //0x38, Offset to "Image"
	u32 img_len;                    //0x3C, Length of "Image"
	u32 img_crc32;                  //0x40, CRC32 of data
        u32 img_flags;                  //0x44, Multiple flags:
                                        //  [0] - AES encrypted
                                        //  [1] - anti-rollback on
                                        //  [2] - Secondary Flag
                                        //  [3] - Secure boot enable
                                        //  [31:4] - TBD
#define BIF_IS_ENCRYPTED	(1<<0)
#define BIF_IS_ANTI_ROLLBACK_ON	(1<<1)
#define BIF_IS_SECONDARY	(1<<2)
#define BIF_SECURE_BOOT_EN	(1<<3)
        u32 keys_revocation;            //0x48, Revocation for ec and aes keys, 1 to revoke relevant key
                                        // [31:27] - reserved
                                        // [26:24] - AES keys revocation
                                        // [23:16] - ec_pubkey_table #2 keys revocation
                                        // [15:8] - ec_pubkey_table #1 keys revocation
                                        // [7:0] - ec_pubkey_table #0 keys revocation
	u8 reserved2[4];
	u8 aes_iv[16];                  //0x50, the AES-256 IV
	struct ec_params ec_params;     //0x60, EC-256 curve parameters:
	u32 ekek[8];			//0x160, Encrypted Key Encryption Key
	u32 edek[8];			//0x180, Encrypted Data Encryption Key
};

struct image_conf
{
	char     inputfile      [MAX_PATH_LEN];
	uint32_t princed_aes_key[8];
	uint32_t princed_dbg_key[4];


	//all options can be defined in the inputfile and be overrided by argv[]
	char     image_bin                             [MAX_PATH_LEN]; int has_image_bin                         ;
	char     image_flags_sz                        [MAX_PATH_LEN]; int has_image_flags_sz                    ;
	uint32_t image_flags;
	uint32_t image_entry_l                                       ; int has_image_entry_l                     ;
	uint32_t image_entry_h                                       ; int has_image_entry_h                     ;
	uint32_t image_version                                       ; int has_image_version                     ;
	uint32_t otp_nv_counter_off                                  ; int has_otp_nv_counter_off                ; 
	uint32_t otp_img_aes_key_idx                                 ; int has_otp_img_aes_key_idx               ; 
	uint32_t otp_pubkey_table_idx                                ; int has_otp_pubkey_table_idx              ;

	char     ec_pri_keys    [BIF_MAX_EC_PUBKEY_NUM][MAX_PATH_LEN]; int has_ec_pri_keys  [BIF_MAX_EC_PUBKEY_NUM];
	uint32_t ec_key_sel                                          ; int has_ec_key_sel                          ;
	uint32_t ec_key_count;
	struct ec_pubkey ec_pubkeys           [BIF_MAX_EC_PUBKEY_NUM];

	uint32_t ec_param_p                                       [8]; int has_ec_param_p                          ;
	uint32_t ec_param_a                                       [8]; int has_ec_param_a                          ;
	uint32_t ec_param_b                                       [8]; int has_ec_param_b                          ;
	uint32_t ec_param_gx                                      [8]; int has_ec_param_gx                         ;
	uint32_t ec_param_gy                                      [8]; int has_ec_param_gy                         ;
	uint32_t ec_param_n                                       [8]; int has_ec_param_n                          ;
	uint32_t ec_sign_kinv                                     [8]; int has_ec_sign_kinv                        ;
	uint32_t ec_sign_rp                                       [8]; int has_ec_sign_rp                          ;

	char     aes_key_file                          [MAX_PATH_LEN]; int has_aes_key_file                        ;
	uint32_t aes_key                                          [8];
	char     aes_iv_file                           [MAX_PATH_LEN]; int has_aes_iv_file                         ;
	uint32_t aes_iv                                           [4];

	char     aes_kek_file                          [MAX_PATH_LEN]; int has_aes_kek_file                        ;
	uint32_t aes_kek                                          [8];
	char     aes_dek_file                          [MAX_PATH_LEN]; int has_aes_dek_file                        ;
	uint32_t aes_dek                                          [8];

	char     output_image_bin_cipher_filename      [MAX_PATH_LEN]; int has_output_image_bin_cipher_filename    ;
	char     output_image_hdr_filename             [MAX_PATH_LEN]; int has_output_image_hdr_filename           ;
	char     output_image_hash_filename            [MAX_PATH_LEN]; int has_output_image_hash_filename          ;
	char     output_image_sig_filename             [MAX_PATH_LEN]; int has_output_image_sig_filename           ;
//	char     output_aes_iv_filename                [MAX_PATH_LEN]; int has_output_aes_iv_filename              ;
	char     output_otpscr_filename                [MAX_PATH_LEN]; int has_output_otpscr_filename              ;

	uint32_t keys_revocation                                     ; int has_keys_revocation                     ;
};

// all available config strings
#define CONF_IMAGE_BIN                          "IMAGE_BIN"
#define CONF_IMAGE_FLAGS                        "IMAGE_FLAGS"
#define CONF_IMAGE_ENTRYPOINT_L                 "IMAGE_ENTRYPOINT_L"
#define CONF_IMAGE_ENTRYPOINT_H                 "IMAGE_ENTRYPOINT_H"
#define CONF_IMAGE_VERSION                      "IMAGE_VERSION"
#define CONF_OTP_NV_COUNTER_OFF                 "OTP_NV_COUNTER_OFF"
#define CONF_OTP_IMG_AES_KEY_IDX                "OTP_IMG_AES_KEY_IDX"
#define CONF_OTP_PUBKEY_TABLE_IDX               "OTP_PUBKEY_TABLE_IDX"
#define CONF_EC_PRI_KEY_0                       "EC_PRI_KEY_0"
#define CONF_EC_PRI_KEY_1                       "EC_PRI_KEY_1"
#define CONF_EC_PRI_KEY_2                       "EC_PRI_KEY_2"
#define CONF_EC_PRI_KEY_3                       "EC_PRI_KEY_3"
#define CONF_EC_PRI_KEY_4                       "EC_PRI_KEY_4"
#define CONF_EC_PRI_KEY_5                       "EC_PRI_KEY_5"
#define CONF_EC_PRI_KEY_6                       "EC_PRI_KEY_6"
#define CONF_EC_PRI_KEY_7                       "EC_PRI_KEY_7"
#define CONF_EC_KEY_SEL                         "EC_KEY_SEL"
#define CONF_EC_PARAM_P                         "EC_PARAM_P"
#define CONF_EC_PARAM_A                         "EC_PARAM_A"
#define CONF_EC_PARAM_B                         "EC_PARAM_B"
#define CONF_EC_PARAM_GX                        "EC_PARAM_GX"
#define CONF_EC_PARAM_GY                        "EC_PARAM_GY"
#define CONF_EC_PARAM_N                         "EC_PARAM_N"
#define CONF_EC_SIGN_KINV                       "EC_SIGN_KINV"
#define CONF_EC_SIGN_RP                         "EC_SIGN_RP"
#define CONF_AES_KEY                            "AES_KEY"
#define CONF_AES_IV                             "AES_IV"
#define CONF_AES_KEK                            "AES_KEK"
#define CONF_AES_DEK                            "AES_DEK"
#define CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME   "OUTPUT_IMAGE_BIN_CIPHER_FILENAME"
#define CONF_OUTPUT_IMAGE_HDR_FILENAME          "OUTPUT_IMAGE_HDR_FILENAME"
#define CONF_OUTPUT_IMAGE_HASH_FILENAME         "OUTPUT_IMAGE_HASH_FILENAME"
#define CONF_OUTPUT_IMAGE_SIG_FILENAME          "OUTPUT_IMAGE_SIG_FILENAME"
#define CONF_OUTPUT_OTPSCR_FILENAME             "OUTPUT_OTPSCR_FILENAME"
#define CONF_KEYS_REVOCATION                    "KEYS_REVOCATION"

#endif
