/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file parse_utils.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __PARSE_UTILS_H__
#define __PARSE_UTILS_H__

#include <stdint.h>

#define MAX_INPUT_OPTION_NAME_LEN     64
#define MAX_INPUT_OPTION_LINE_LEN     512
#define MAX_INPUT_FIELD_LEN           128
#define MAX_INPUT_FIELD_NUM           64

struct input_field
{
    char s[MAX_INPUT_FIELD_LEN];
};

struct input_option
{
    char name[MAX_INPUT_OPTION_NAME_LEN];
    int num;
    struct input_field fields[MAX_INPUT_FIELD_NUM];
};

struct input_script
{
    const char *name;
    uint32_t offset;
    uint32_t offset_has_flag;
    int size;
    int count;
    int (*parser)(const char *s, void *out, int size);
};

#define DEFINE_INPUT_SCRIPT_1(name,type,member,parser) \
    {name,offsetof(type,member),offsetof(type,has_##member),sizeof(((type*)0)->member),1,parser}

#define DEFINE_INPUT_SCRIPT_N(name,type,member,parser) \
    {name,offsetof(type,member),offsetof(type,has_##member),sizeof(((type*)0)->member[0]),ARRAY_SIZE(((type*)0)->member),parser}

//int parse_input_options(void *outbase, const struct input_script *script, int count);
int parse_input_options(void *outbase, const struct input_script *script, int scripts_num, const char *interest[], int interest_num);
void print_input_file(void);
int parse_input_file(const char *file);
const struct input_option *find_input_option(const char *name);

int parser_read_s(const char *s, void *out, int size);
int parser_read_w_le(const char *s, void *out, int size);
int parser_read_w_be(const char *s, void *out, int size);
int parser_read_dw_le(const char *s, void *out, int size);
int parser_read_dw_be(const char *s, void *out, int size);
int parser_read_hexstr(const char *s, void *out, int size);

int parse_hexstr_file(const char *file, void *out, int size);
uint32_t parse_image_flags(const char *s);

const char *basename(const char *path);
size_t filesize(const char *path);
size_t loadfile(const char *path, void *buf);
int savefile(const char *path, void *buf, size_t len);
int copyfile(const char *dst_path, const char *src_path);

void reverse_w(uint32_t *data, int count);
void reverse_w_be2le(uint32_t *data, int count);

#endif
