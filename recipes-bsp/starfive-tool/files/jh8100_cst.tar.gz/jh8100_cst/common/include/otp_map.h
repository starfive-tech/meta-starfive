#ifndef __OTP_MAP_H__
#define __OTP_MAP_H__

#define OTP1_BASE                    0x1400
#define OTP1_CPM_EN                  0x00 //0x1400
#define OTP1_PPM_DBG_EN              0x10 //0x1410
#define OTP1_DEBUG_MODE              0x14 //0x1414
#define OTP1_SECURE_BOOT             0x18 //0x1418
#define   SECURE_BOOT_EN             0xffffffff
#define OTP1_BOOT_KEY_ENTRY          0x1c //0x141c
#define   BOOT_KEY_ENTRY_FIX_0       0xffffffff
#define OTP1_Kfw_0                   0x20 //0x1420
#define OTP1_Kfw_1                   0x40 //0x1440
#define OTP1_Kfw_2                   0x60 //0x1460
#define OTP1_Kdbg                    0x80 //0x1480

#define OTP2_BASE                    0x0
#define OTP2_HASHPUK_0               0x0
#define OTP2_HASHPUK_1               0x20
#define OTP2_HASHPUK_2               0x40
#define OTP2_UID                     0x80
#define OTP2_PD_DDR1_OFF             0x88
#define OTP2_PD_USB3_OFF             0x8c
#define OTP2_CPUCL_S_FREQ            0x90
#define OTP2_XIP_EN                  0x94
#define OTP2_SECONDARY_BOOT_HDRLOC   0x98

#endif
