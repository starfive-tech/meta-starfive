#ifndef __TOOLS_CRYPTO_UTILS_H__
#define __TOOLS_CRYPTO_UTILS_H__

#include <sha.h>
#include <aes.h>
#include <ec.h>
#include <prince.h>

int crypto_rand_bytes(uint8_t *buf, int num);
uint8_t *crypto_string_to_hex(const char *str, long *buflen);

#endif
