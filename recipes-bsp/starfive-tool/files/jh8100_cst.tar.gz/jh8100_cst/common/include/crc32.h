/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file crc32.h
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#ifndef __TOOLS_CRC32_H__
#define __TOOLS_CRC32_H__

uint32_t crc32_mpeg(const char *buf, int len);
uint32_t crc32(uint32_t crc, const char *buf, size_t len);
int crc32_file(const char *path, uint32_t *crc);

int crc32_init(void);
int crc32_update(const char *buf, size_t len);
int crc32_update_file(const char *path);
int crc32_final(uint32_t *crc);

#endif
