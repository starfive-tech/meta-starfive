/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file app_common.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <parse_utils.h>
#include <debug_utils.h>
#include <crypto_utils.h>
#include <global.h>
#include <app_common.h>
#include <crc32.h>

static int app_load_ec_pubkey(const char *path, struct ec_pubkey *pubkey);

static const struct input_script g_scripts[] = {
	DEFINE_INPUT_SCRIPT_1(CONF_IMAGE_BIN                           , struct image_conf, image_bin                           , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_IMAGE_FLAGS                         , struct image_conf, image_flags_sz                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_IMAGE_ENTRYPOINT_L                  , struct image_conf, image_entry_l                       , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_IMAGE_ENTRYPOINT_H                  , struct image_conf, image_entry_h                       , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_IMAGE_VERSION                       , struct image_conf, image_version                       , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_OTP_NV_COUNTER_OFF                  , struct image_conf, otp_nv_counter_off                  , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_OTP_IMG_AES_KEY_IDX                 , struct image_conf, otp_img_aes_key_idx                 , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_OTP_PUBKEY_TABLE_IDX                , struct image_conf, otp_pubkey_table_idx                , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_0                        , struct image_conf, ec_pri_keys[0]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_1                        , struct image_conf, ec_pri_keys[1]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_2                        , struct image_conf, ec_pri_keys[2]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_3                        , struct image_conf, ec_pri_keys[3]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_4                        , struct image_conf, ec_pri_keys[4]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_5                        , struct image_conf, ec_pri_keys[5]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_6                        , struct image_conf, ec_pri_keys[6]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PRI_KEY_7                        , struct image_conf, ec_pri_keys[7]                      , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_KEY_SEL                          , struct image_conf, ec_key_sel                          , parser_read_w_le),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_P                          , struct image_conf, ec_param_p                          , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_A                          , struct image_conf, ec_param_a                          , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_B                          , struct image_conf, ec_param_b                          , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_GX                         , struct image_conf, ec_param_gx                         , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_GY                         , struct image_conf, ec_param_gy                         , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_PARAM_N                          , struct image_conf, ec_param_n                          , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_SIGN_KINV                        , struct image_conf, ec_sign_kinv                        , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_EC_SIGN_RP                          , struct image_conf, ec_sign_rp                          , parser_read_hexstr),
	DEFINE_INPUT_SCRIPT_1(CONF_AES_KEY                             , struct image_conf, aes_key_file                        , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_AES_IV                              , struct image_conf, aes_iv_file                         , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_AES_KEK                             , struct image_conf, aes_kek_file                        , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_AES_DEK                             , struct image_conf, aes_dek_file                        , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_IMAGE_BIN_CIPHER_FILENAME    , struct image_conf, output_image_bin_cipher_filename    , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_IMAGE_HDR_FILENAME           , struct image_conf, output_image_hdr_filename           , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_IMAGE_HASH_FILENAME          , struct image_conf, output_image_hash_filename          , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_IMAGE_SIG_FILENAME           , struct image_conf, output_image_sig_filename           , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_OTPSCR_FILENAME              , struct image_conf, output_otpscr_filename              , parser_read_s   ),
//	DEFINE_INPUT_SCRIPT_1(CONF_OUTPUT_AES_IV_FILENAME              , struct image_conf, output_aes_iv_filename              , parser_read_s   ),
	DEFINE_INPUT_SCRIPT_1(CONF_KEYS_REVOCATION                     , struct image_conf, keys_revocation                     , parser_read_w_le),
};

//relative path to exec home
static void app_normalize_path(const struct image_conf *conf, char *path, int size)
{
	if (path[0] != '/' && path[1] != ':') {
		char abs_path[MAX_PATH_LEN] = "";
		const char *p = NULL;
		if ((p = strrchr(conf->inputfile, '/')) || (p = strrchr(conf->inputfile, '\\')))
			strncpy(abs_path, conf->inputfile, p - conf->inputfile + 1);
		strcat(abs_path, path);
		strncpy(path, abs_path, MAX_PATH_LEN);
	}
}

static int app_load_aes_key(const char *path, uint32_t *out, int out_size)
{
	return parse_hexstr_file(path, out, out_size);
}

static int app_load_aes_iv(const char *path, uint32_t *out, int out_size)
{
	return parse_hexstr_file(path, out, out_size);
}

int app_load_conf(const char *input_file, struct image_conf *conf, const char *interest[], int interest_num)
{
	parser_read_s(input_file, conf->inputfile, sizeof(conf->inputfile));
	if (parse_input_file(conf->inputfile) == 0) {
		return -EINVAL;
	}
	if (parse_input_options(conf, g_scripts, ARRAY_SIZE(g_scripts), interest, interest_num)) {
		return -EINVAL;
	}

	// parse pubkey
	int ec_key_count = 0;
	int i;
	for (i = 0; i < BIF_MAX_EC_PUBKEY_NUM; i++) {
		if (conf->has_ec_pri_keys[i]) {
			app_normalize_path(conf, conf->ec_pri_keys[i], sizeof(conf->ec_pri_keys[i]));
			if (app_load_ec_pubkey(conf->ec_pri_keys[i], &conf->ec_pubkeys[i])) {
				printf("failed to load ec_pri_key #%d: %s\n", i, conf->ec_pri_keys[i]);
				return -EINVAL;
			}
			ec_key_count++;
		}
	}
	conf->ec_key_count = ec_key_count;

	// parse image flags
	if (conf->has_image_flags_sz)
		conf->image_flags = parse_image_flags(conf->image_flags_sz);

	// aes key file
	if (conf->has_aes_key_file) {
		app_normalize_path(conf, conf->aes_key_file, sizeof(conf->aes_key_file));
		if (app_load_aes_key(conf->aes_key_file, conf->aes_key, sizeof(conf->aes_key))) {
			printf("failed to load aes_key: %s\n", conf->aes_key_file);
			return -EINVAL;
		}
	}
	
	// aes iv file
	if (conf->has_aes_iv_file) {
		app_normalize_path(conf, conf->aes_iv_file, sizeof(conf->aes_iv_file));
		if (app_load_aes_iv(conf->aes_iv_file, conf->aes_iv, sizeof(conf->aes_iv))) {
			printf("failed to load aes_iv: %s\n", conf->aes_iv_file);
			return -EINVAL;
		}
	}

	// aes kek file
	if (conf->has_aes_kek_file) {
		app_normalize_path(conf, conf->aes_kek_file, sizeof(conf->aes_kek_file));
		if (app_load_aes_key(conf->aes_kek_file, conf->aes_kek, sizeof(conf->aes_kek))) {
			printf("failed to load aes_kek: %s\n", conf->aes_kek_file);
			return -EINVAL;
		}
	}

	// aes dek file
	if (conf->has_aes_dek_file) {
		app_normalize_path(conf, conf->aes_dek_file, sizeof(conf->aes_dek_file));
		if (app_load_aes_key(conf->aes_dek_file, conf->aes_dek, sizeof(conf->aes_dek))) {
			printf("failed to load aes_dek: %s\n", conf->aes_dek_file);
			return -EINVAL;
		}
	}

	return 0;
}

void app_print_conf(const struct image_conf *conf)
{
	int i;

    //for easy debug message alignment with column-editing, we disobey the coding style here
	printf("configuration:\n");
	printf("  inputfile            : %s\n", conf->inputfile);
	if (conf->has_image_bin           ) { printf("  image_bin            : %s\n", conf->image_bin); }
	if (conf->has_image_flags_sz      ) { printf("  image_flags          : %s (0x%x)\n", conf->image_flags_sz, conf->image_flags); }
	if (conf->has_image_entry_h       ) { printf("  image_entry_h        : 0x%x\n", conf->image_entry_h); }
	if (conf->has_image_entry_l       ) { printf("  image_entry_l        : 0x%x\n", conf->image_entry_l); }
	if (conf->has_image_version       ) { printf("  image_version        : %d\n", conf->image_version); }
	if (conf->has_otp_nv_counter_off  ) { printf("  otp_nv_counter_off   : 0x%x\n", conf->otp_nv_counter_off  ); }
	if (conf->has_otp_img_aes_key_idx ) { printf("  otp_img_aes_key_idx  : 0x%x\n", conf->otp_img_aes_key_idx ); }
	if (conf->has_otp_pubkey_table_idx) { printf("  otp_pubkey_table_idx : 0x%x\n", conf->otp_pubkey_table_idx); }
	
//     if (conf->has_ec_pri_keys   ) { printf("  ec_pri_keys    : %s %s %s %s\n", conf->ec_pri_keys[0], conf->ec_pri_keys[1], conf->ec_pri_keys[2], conf->ec_pri_keys[3]); }
	for (i = 0; i < ARRAY_SIZE(conf->has_ec_pri_keys); i++) {
		if (conf->has_ec_pri_keys[i])
			printf("  ec_pri_key_%d   : %s\n", i, conf->ec_pri_keys[i]);
	}
	if (conf->ec_key_count) { 
		printf("  ec_key_sel     : %d\n", conf->ec_key_sel);
		printf("  ec_key_count   : %d\n", conf->ec_key_count);
	}

	if (conf->has_ec_param_p    ) { printf("  ec_param_p     : "); dump_words_line(stdout, conf->ec_param_p  , sizeof(conf->ec_param_p  ), " ", 0); }
	if (conf->has_ec_param_a    ) { printf("  ec_param_a     : "); dump_words_line(stdout, conf->ec_param_a  , sizeof(conf->ec_param_a  ), " ", 0); }
	if (conf->has_ec_param_b    ) { printf("  ec_param_b     : "); dump_words_line(stdout, conf->ec_param_b  , sizeof(conf->ec_param_b  ), " ", 0); }
	if (conf->has_ec_param_gx   ) { printf("  ec_param_gx    : "); dump_words_line(stdout, conf->ec_param_gx , sizeof(conf->ec_param_gx ), " ", 0); }
	if (conf->has_ec_param_gy   ) { printf("  ec_param_gy    : "); dump_words_line(stdout, conf->ec_param_gy , sizeof(conf->ec_param_gy ), " ", 0); }
	if (conf->has_ec_param_n    ) { printf("  ec_param_n     : "); dump_words_line(stdout, conf->ec_param_n  , sizeof(conf->ec_param_n  ), " ", 0); }
	if (conf->has_ec_sign_kinv  ) { printf("  ec_sign_kinv   : "); dump_words_line(stdout, conf->ec_sign_kinv, sizeof(conf->ec_sign_kinv), " ", 0); }
	if (conf->has_ec_sign_rp    ) { printf("  ec_sign_rp     : "); dump_words_line(stdout, conf->ec_sign_rp  , sizeof(conf->ec_sign_rp  ), " ", 0); }
	if (conf->has_aes_key_file  ) { printf("  aes_key        : %s\n", conf->aes_key_file); }
	if (conf->has_aes_iv_file   ) { printf("  aes_iv         : %s\n", conf->aes_iv_file ); }
	if (conf->has_aes_kek_file  ) { printf("  aes_kek        : %s\n", conf->aes_kek_file); }
	if (conf->has_aes_dek_file  ) { printf("  aes_dek        : %s\n", conf->aes_dek_file); }

	if (conf->has_output_image_bin_cipher_filename) { printf("  output_image_bin_cipher_filename: %s\n", conf->output_image_bin_cipher_filename); }
	if (conf->has_output_image_hdr_filename       ) { printf("  output_image_hdr_filename       : %s\n", conf->output_image_hdr_filename       ); }
	if (conf->has_output_image_hash_filename      ) { printf("  output_image_hash_filename      : %s\n", conf->output_image_hash_filename      ); }
	if (conf->has_output_image_sig_filename       ) { printf("  output_image_sig_filename       : %s\n", conf->output_image_sig_filename       ); }
//	if (conf->has_output_aes_iv_filename          ) { printf("  output_aes_iv_filename          : %s\n", conf->output_aes_iv_filename          ); }

	if (conf->has_keys_revocation){ printf("  keys_revocation: 0x%08x\n", conf->keys_revocation); }
}

int app_load_ec_params(const struct image_conf *conf, struct ec_params *ec_params)
{
	memcpy(ec_params->p,  conf->ec_param_p,  sizeof(ec_params->p ));
	memcpy(ec_params->a,  conf->ec_param_a,  sizeof(ec_params->a ));
	memcpy(ec_params->b,  conf->ec_param_b,  sizeof(ec_params->b ));
	memcpy(ec_params->gx, conf->ec_param_gx, sizeof(ec_params->gx));
	memcpy(ec_params->gy, conf->ec_param_gy, sizeof(ec_params->gy));
	memcpy(ec_params->n,  conf->ec_param_n,  sizeof(ec_params->n ));
	return 0;
}

static int app_load_ec_pubkey(const char *path, struct ec_pubkey *pubkey)
{
	void *ec_key = NULL;
	ec_key = ec_loadkey(path);
	if (!ec_key) {
		printf("load ec_pubkey from %s failed\n", path);
		return 1;
	}
	if (ec_pubkey2bin(ec_key, (uint8_t*)pubkey, sizeof(struct ec_pubkey))) {
		printf("illegal ec_pubkey: path %s\n", path);
		return 1;
	}
	return 0;
}

static void gen_nv_counter(int input, uint8_t *out, int out_size)
{
	int i;

	memset(out, 0, out_size);
	for (i = 0; i < input; i++) {
		out[out_size - 1 - (i>>3)] |= 1<<(i&7);
	}
}

int app_gen_image_hdr(const struct image_conf *conf, struct image_hdr *hdr)
{
	if (!conf || !hdr) {
		return -EINVAL;
	}
	memset(hdr, 0, sizeof(*hdr));

	hdr->magic_num = BIF_MAGIC_NUM;
	hdr->bif_version = BIF_VERSION_1;
	hdr->entry_point_l = conf->image_entry_l;
	hdr->entry_point_h = conf->image_entry_h;
	
	if (conf->image_flags & BIF_IS_ANTI_ROLLBACK_ON) {
		const int MAX_IMAGE_VERSION = BIF_NV_COUNTER_LEN<<3; //bits count of NV_Counter
		if (conf->image_version > MAX_IMAGE_VERSION) {
			fprintf(stderr, "invalid image_version %d\n", conf->image_version);
			return -EINVAL;
		}
		gen_nv_counter(conf->image_version, (uint8_t*)hdr->nv_counter, sizeof(hdr->nv_counter));
		debug_dump_words_line(stdout, hdr->nv_counter, sizeof(hdr->nv_counter), ",", 0);
	}
	hdr->otp_nv_counter_off = conf->otp_nv_counter_off;
	hdr->otp_img_aes_key_idx = conf->otp_img_aes_key_idx;
	hdr->otp_pubkey_table_idx = conf->otp_pubkey_table_idx;

	hdr->ec_pubkey_table_off = 0; //update later
	hdr->ec_pubkey_count = conf->ec_key_count;
	hdr->ec_pubkey_select = conf->ec_key_sel;

	hdr->sign_off = 0; //update later:
	hdr->sign_len = sizeof(struct ecdsa_sig);

	hdr->img_off = 0; //update later
	hdr->img_len = filesize(conf->image_bin);
	hdr->img_crc32 = 0;
	if (crc32_file(conf->image_bin, &hdr->img_crc32)) {
		fprintf(stderr, "failed to calculate crc32.\n");
		return 1;
	}
	hdr->img_flags = conf->image_flags;
	memcpy(hdr->aes_iv, conf->aes_iv, sizeof(hdr->aes_iv));

	if (app_load_ec_params(conf, &hdr->ec_params)) {
		fprintf(stderr, "failed to load ec_params.\n");
		return 1;
	}

	if (conf->has_aes_kek_file) {
		if (aes256_cbc_crypt(1, 0, (uint8_t*)conf->aes_key, (uint8_t*)conf->aes_iv,
			(uint8_t*)conf->aes_kek, sizeof(conf->aes_kek),
			(uint8_t*)hdr->ekek, sizeof(hdr->ekek)) <= 0) {
			fprintf(stderr, "failed to do encrypt kek\n");
			return 1;
		}
		printf("ekek:\n");
		dump_bytes_line(stdout, hdr->ekek, sizeof(hdr->ekek), NULL);
	}

	if (conf->has_aes_dek_file) {
		if (aes256_cbc_crypt(1, 0, (uint8_t*)conf->aes_kek, (uint8_t*)conf->aes_iv,
			(uint8_t*)conf->aes_dek, sizeof(conf->aes_dek),
			(uint8_t*)hdr->edek, sizeof(hdr->edek)) <= 0) {
			fprintf(stderr, "failed to do encrypt dek\n");
			return 1;
		}
		printf("edek:\n");
		dump_bytes_line(stdout, hdr->edek, sizeof(hdr->edek), NULL);
	}

	if (conf->has_keys_revocation)
		hdr->keys_revocation = conf->keys_revocation;

	return 0;
}

int app_gen_image_hash(const struct image_conf *conf, const struct image_hdr *hdr, uint8_t *hash, int hash_len)
{
    if (!conf || !hdr || !hash || hash_len < SHA256_HASH_LEN) {
        return -EINVAL;
    }
    if (sha256_init() ||
        sha256_update((uint8_t*)hdr, sizeof(*hdr)) ||
        sha256_update_file(conf->image_bin) ||
        sha256_final(hash, hash_len)) {
            fprintf(stderr, "sha256 fail\n");
            return -EINVAL;
    }

    return 0;
}

int app_validate_ec_key(const struct image_conf *conf, int key_sel)
{
    if (key_sel < 0 || key_sel >= conf->ec_key_count) {
        return -EINVAL;
    }
    return 0;
}
