/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file parse_utils.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <parse_utils.h>
#include <debug_utils.h>
#include <global.h>

static char *readline(FILE *fp);
static char* trim(char *s);
static int read_input_option(char *s, struct input_option *opt);
static int parse_input_option_value(char *s, struct input_option *opt);

struct input_config
{
    char filename[512];
    int input_option_num;
    struct input_option input_option_buf[2048];
};

static struct input_config config;

// xxxxxxxx yyyyyyyy zzzzzzzz => zzzzzzzz yyyyyyyy xxxxxxxx
void reverse_w(uint32_t *data, int count)
{
    uint32_t temp;
    for (int i = (count - 1) >> 1; i >= 0; i--) {
        temp = data[i];
        data[i] = data[count - 1 - i];
        data[count - 1 - i] = temp;
    }
}

// 01020304 05060708 0a0b0c0d => 0d0c0b0a 08070605 04030201
void reverse_w_be2le(uint32_t *data, int count)
{
    uint32_t temp;
    for (int i = (count - 1) >> 1; i >= 0; i--) {
        temp = read32_be(data + i);
        data[i] = read32_be(data + count - 1 - i);
        data[count - 1 - i] = temp;
    }
}

int parser_read_s(const char *s, void *out, int size)
{
    char *s_out = (char*)out;
    strncpy(s_out, s, size - 1);
    return (s_out[0] == '\0');
}

int parser_read_w_le(const char *s, void *out, int size)
{
    uint32_t *w_out = (uint32_t *)out;
    int base;
    char *endptr = NULL;
    long value = 0;
    int sign = 1;
    
    base = (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) ? 16 : 10;
    if (s[0] == '-') {
	    sign = -1;
	    printf("negative value: %s\n", s);
	    s++;
    }
    value = strtol(s, &endptr, base);
    *w_out = (uint32_t)value;
    if ((long)(*w_out) != value) {
        printf("integer overflow: '%s', w_out %ld, value %ld\n", s, (long)(*w_out), value);
        return -EOVERFLOW;
    }
    *w_out *= sign;
    return (s == endptr);
}

int parser_read_w_be(const char *s, void *out, int size)
{
    uint32_t w_le = 0;
    int ret = parser_read_w_le(s, &w_le, sizeof(w_le));
    if (ret) {
        return ret;
    }
    uint32_t *w_out = (uint32_t *)out;
    *w_out = read32_be(&w_le);
    return 0;
}

int parser_read_dw_le(const char *s, void *out, int size)
{
    uint64_t *dw_out = (uint64_t *)out;
    int base;
    char *endptr = NULL;
    long long value = 0;
    
    base = (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) ? 16 : 10;
    value = strtoll(s, &endptr, base);
    *dw_out = (uint64_t)value;
    if ((long long)(*dw_out) != value) {
        printf("integer overflow: '%s'\n", s);
        return -EOVERFLOW;
    }
    return (s == endptr);
}

int parser_read_dw_be(const char *s, void *out, int size)
{
    uint64_t dw_le = 0;
    int ret = parser_read_dw_le(s, &dw_le, sizeof(dw_le));
    if (ret) {
        return ret;
    }
    uint64_t *dw_out = (uint64_t *)out;
    *dw_out = read64_be(&dw_le);
    return 0;
}

int parser_read_hexstr(const char *s, void *out, int size)
{
#define DIGIT_VALUE(c) ({ 							\
		char __c = (c);							\
		int __val;							\
		__val = (__c >= '0' && __c <= '9') ? (__c - '0') : ( 		\
			(__c >= 'a' && __c <= 'f') ? (__c - 'a' + 0xa) : ( 	\
			(__c >= 'A' && __c <= 'f') ? (__c - 'A' + 0xA) : -1));	\
		__val;								\
	})

	char buf[3];
	uint8_t *p = (uint8_t *)out;
	int n = 0, temp;
	while (*s && size > 0) {
		buf[n & 1] = *s++;
		if (n++ & 1) {
			buf[2] = '\0';
			temp = DIGIT_VALUE(buf[0]);
			if (temp < 0)
				break;
			*p = (uint8_t)(temp << 4);
			temp = DIGIT_VALUE(buf[1]);
			if (temp < 0)
				break;
			*p += (uint8_t)temp;
			p++;
			size--;
		}
	}

	return size != 0 || *s;
}

int parse_hexstr_file(const char *file, void *out, int size)
{
	FILE *fp = NULL;
	char *line = NULL;
	int line_no = 0;
	
	fp = fopen(file, "r");
	if (!fp) {
		ERROR_LOG("can't read file: %s\n", file);
		return 1;
	}
	while ((line = readline(fp)) != NULL) {
		line_no++;
		if (line[0] == '\0' || line[0] == '#') {
			//empty or comment line
			continue;
		}
		line = trim(line);
		debug_printf("ln %d:%s\n", line_no, line);
		if (!parser_read_hexstr(line, out, size)) {
			break;
		}
	}

	fclose(fp);
	return 0;
}

uint32_t parse_image_flags(const char *s)
{
	uint32_t value = 0;
	int i;
	const struct {
		const char *name;
		uint32_t value;
	} FLAGS[] = {
		{"ENCRYPTED", 		BIF_IS_ENCRYPTED	},
		{"ANTI_ROLLBACK_ON", 	BIF_IS_ANTI_ROLLBACK_ON	},
		{"SECONDARY", 		BIF_IS_SECONDARY	},
		{"SECURE_BOOT_EN", 	BIF_SECURE_BOOT_EN	},
	};

	while (s && *s) {
		char *sep = strchr(s, '|');
		char buf[64] = {0};
		strncpy(buf, s, sep ? (sep - s) : sizeof(buf) - 1);
		char *name = trim(buf);
		debug_printf("set image flag:'%s'\n", name);
		for (i = 0; i < ARRAY_SIZE(FLAGS); i++) {
			if (strcmp(name, FLAGS[i].name) == 0)
				value |= FLAGS[i].value;
		}
		s = sep ? sep + 1 : sep;
	}

	return value;
}

static int find_string_in_table(const char *s, const char *tbl[], int tbl_num)
{
	for (int i = 0; i < tbl_num; i++) {
		if (tbl[i] && strcmp(s, tbl[i]) == 0)
			return 0;
	}
	return 1;
}

int parse_input_options(void *outbase, const struct input_script *script, int scripts_num, const char *interest[], int interest_num)
{
    const struct input_option *input_option = NULL;
    uint8_t *outptr = NULL;
    int *has_flag = NULL, i, j;

    if (!outbase || !script) {
        return -EINVAL;
    }

    for (i = 0; i < scripts_num; i++, script++) {
        if (interest && interest_num > 0
                && find_string_in_table(script->name, interest, interest_num)) {
                //ignore uninterest conf
                continue;
        }

        input_option = find_input_option(script->name);
        if (input_option && script->parser) {
            outptr = (uint8_t*)outbase + script->offset;
            has_flag = (int*)((uint8_t*)outbase + script->offset_has_flag);
            if (*has_flag) {
                continue;
            }
            
            int loaded = 0;
            //printf("input_option %20s: .name %20s, offset %4d, offset_has_flag %4d, size %4d, count %4d\n",
            //    input_option->name, script->name, script->offset, script->offset_has_flag, script->size, script->count);
            for (j = 0; j < script->count && j < input_option->num; j++, outptr += script->size) {
                //printf("  %d:%s\n", j, input_option->fields[j].s);
                if (script->parser(input_option->fields[j].s, outptr, script->size)) {
                    printf("parse %s:%s error\n", input_option->name, input_option->fields[j].s);
                    //memset(outptr, 0, script->size);
		    return -EINVAL;
                } else {
                    loaded++;
                }
            }
            *has_flag = loaded ? 1 : 0;
        }
    }
    return 0;
}

void print_input_file(void)
{
    printf("input: %s\n", config.filename);
    for (int i = 0; i < config.input_option_num; i++) {
        printf("%s:\n", config.input_option_buf[i].name);
        for (int j = 0; j < config.input_option_buf[i].num; j++) {
            printf("  %s\n", config.input_option_buf[i].fields[j].s);
        }
    }
}

int parse_input_file(const char *file)
{
    FILE *fp = NULL;
    char *line = NULL;
    int line_no = 0;

    config.input_option_num = 0;

    fp = fopen(file, "r");
    if (!fp) {
        ERROR_LOG("can't read input file: %s\n", file);
        exit(1);
    }
    while ((line = readline(fp)) != NULL) {
        line_no++;
        if (line[0] == '\0' || line[0] == '#') {
            //empty or comment line
            continue;
        }
	debug_printf("ln %d:%s\n", line_no, line);
        if (!read_input_option(line, config.input_option_buf + config.input_option_num)) {
            config.input_option_num++;
        }
    }

    fclose(fp);

    return config.input_option_num;
}

const struct input_option *find_input_option(const char *name)
{
    const struct input_option *p = NULL;
    int i;

    if (!name) {
        return NULL;
    }
    
    for (i = 0, p = config.input_option_buf; i < config.input_option_num; i++, p++) {
        if (!strcmp(name, p->name)) {
            return p;
        }
    }
    
    return NULL;
}

const char *basename(const char *path)
{
    char *sep = NULL;
    if ((sep = strrchr(path, '/')) ||
        (sep = strrchr(path, '\\'))) {
        return sep + 1;
    }
    return sep;
}

size_t filesize(const char *path)
{
    size_t size = 0;
    FILE *fp = NULL;

    if (!path) {
        return 0;
    }
    fp = fopen(path, "rb");
    if (!fp) {
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    size = (size_t)ftell(fp);
    return size;
}

size_t loadfile(const char *path, void *buf)
{
    size_t rd_size = 0;
    FILE *fp = NULL;

    if (!path || !buf) {
        return 0;
    }
    fp = fopen(path, "rb");
    if (!fp) {
        return 0;
    }

    size_t rd_once = 0;
    while ((rd_once = fread(buf, 1, 1024, fp)) > 0) {
        buf += rd_once;
        rd_size += rd_once;
    }
    fclose(fp);
    printf("loadfile %s, %ld bytes\n", path, rd_size);
    return rd_size;
}

int savefile(const char *path, void *buf, size_t len)
{
    size_t wr_size = 0;
    FILE *fp = NULL;

    if (!path || !buf) {
        return 0;
    }
    fp = fopen(path, "wb");
    if (!fp) {
        return 0;
    }
    wr_size = fwrite(buf, 1, len, fp);
    fclose(fp);

    if (wr_size != len) {
        fprintf(stderr, "failed to save %s\n", path);
        return -EIO;
    }
    printf("savefile %s, %ld bytes\n", path, len);
    return 0;
}

int copyfile(const char *dst_path, const char *src_path)
{
	if (!dst_path || !src_path) {
		return 0;
	}
	printf("copyfile %s -> %s\n", src_path, dst_path);
	FILE *fsrc = fopen(src_path, "rb");
	if (!fsrc) {
		return 0;
	}
	FILE *fdst = fopen(dst_path, "wb");
	if (!fdst) {
		fclose(fsrc);
		return 0;
	}
	uint8_t buff[16*1024] = {0};
	const int BUFSIZE = sizeof(buff);
	size_t rd = 0;
	int wr_len = 0;
	do {
		rd = fread(buff, 1, BUFSIZE, fsrc);
		if (rd > 0 && fwrite(buff, rd, 1, fdst)) {
			wr_len += rd;
		}
	} while (rd == BUFSIZE);

	fclose(fdst);
	fclose(fsrc);
	return wr_len;	
}

static int read_input_option(char *s, struct input_option *opt)
{
    char *equal = strchr(s, '=');
    if (!equal) {
        return -EINVAL;
    }
    *equal = '\0';
    char *opt_name = s, *opt_value = equal + 1;
    strncpy(opt->name, trim(opt_name), MAX_INPUT_OPTION_NAME_LEN);
    if (!parse_input_option_value(trim(opt_value), opt)) {
        return 0;
    }
    return -ENOTSUP;
}

static int parse_input_option_value(char *s, struct input_option *opt)
{
    const char delims[] = ",";
    debug_printf("%s=%s\n", opt->name, s);
    char *token = strtok(s, delims);

    opt->num = 0;
    while( token != NULL ) {
        debug_printf("  %s\n", trim(token) );
        strncpy(opt->fields[opt->num++].s, trim(token), MAX_INPUT_FIELD_LEN);
        token = strtok(NULL, delims);
    }
    return 0;
}

static char *readline(FILE *fp)
{
    static char line[MAX_INPUT_OPTION_LINE_LEN+1];
    int rd_n = 0, ch = 0;
    
    if (feof(fp)) {
        return NULL;
    }
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == '\n' || rd_n == MAX_INPUT_OPTION_LINE_LEN) {
            break;
        }
        line[rd_n++] = (char)ch;
    }
    line[rd_n] = '\0';
    return line;
}

static char* trim(char *s)
{
    const char *whitechars = " \r\n\t{}";

    //trim left
    while (s && *s && strchr(whitechars, *s)) {
        s++;
    }
    if (s && *s == '\"') {
        s++;
    }

    //trim right
    char *tail = s + strlen(s) - 1;
    while (tail > s && strchr(whitechars, *tail)) {
        *tail-- = '\0';
    }
    if (tail > s && *tail == '\"') {
        *tail = '\0';
    }
    return s;
}
