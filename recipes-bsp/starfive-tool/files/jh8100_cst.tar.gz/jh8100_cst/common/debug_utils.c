#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <debug_utils.h>
#include <global.h>

#define __SWAP_16(a)	( \
	(((u16)(a) & 0xff00) >> 8) | \
	(((u16)(a) & 0x00ff) << 8))

#define __SWAP_32(a)	( \
	(((u32)(a) & 0xff000000) >> 24) | \
	(((u32)(a) & 0x00ff0000) >> 8) | \
	(((u32)(a) & 0x0000ff00) << 8) | \
	(((u32)(a) & 0x000000ff) << 24))

static const union {
	char c[4];
	u32 l;
} __TEST = { .l = 0x0b000001 };

u16 htons(u16 hs)
{
	return (__TEST.c[0] == 0x01) ? __SWAP_16(hs) : hs;
}

u32 htonl(u32 hl)
{
	return (__TEST.c[0] == 0x01) ? __SWAP_32(hl) : hl;
}


void dump(FILE *fp, const void *p, int n)
{
    if (!p && !n) return;
    char symbols[17] = {0};
    const uint8_t *ch = p;
    fprintf(fp, "dump $%p, %d bytes begin:\n", p, n);
    int i, j = 0;
    for (i = 0; i < n; i++, ch++) {
        if ((i&0xf)==0) {
            fprintf(fp, "%08x: ", i);
            j = 0;
            symbols[j] = '\0';
        }

        fprintf(fp, "%02x ", *ch);
        symbols[j++] = (*ch>31 && *ch<127) ? *ch : '.';

        if (((i+1)&0xf)==0) {
            fprintf(fp, "; %s", symbols);
            fprintf(fp, "\n");
        }
    }
    if (i&0xf) {
        fprintf(fp, "%*s ; %s", (i&0xf)*3, " ", symbols);
        fprintf(fp, "\n");
    }
    fprintf(fp, "dump $%p, %d bytes end.\n", p, n);
}

void dump_bytes_line(FILE *fp, const void *p, int n, char *sep)
{
    if (!p && !n) return;
    const uint8_t *ch = p;
    int i;
    for (i = 0; i < n; i++, ch++) {
        fprintf(fp, "%02x%s", *ch, (sep && i<(n-4))? sep :"");
    }
    fprintf(fp, "\n");
}

void dump_words_line(FILE *fp, const void *p, int n, char *sep, int little_endian)
{
    if (!p && !n) return;
    const char *ch = p;
    uint32_t temp;
    int i;
    for (i = 0; i < n; i+=4, ch+=4) {
        temp = little_endian ?  read32_le(ch) : read32_be(ch);
        fprintf(fp, "%08x%s", temp, (sep && i<(n-4))? sep :"");
    }
    fprintf(fp, " (Endian: %s)\n", little_endian ? "Little" : "Big");
}

void dump_xxd(FILE *fp, const char *desc, int g, const void *p, int n, int little_endian)
{
	if (!p || !n)
		return;
	if (g != 1 && g != 2 && g != 4)
		g = 1;
	//offset: <group value> ... <characters>
	//00000000: 11 11 11 11 11 11 11 11 11 11 11 11 11 11 11 11  cccccccccccccccc
	//00000000: 2222 2222 2222 2222 2222 2222 2222 2222  cccccccccccccccc
	//00000000: 44444444 44444444 44444444 44444444  cccccccccccccccc
	//10       +        16/g*(2*g+1)               +1    +16
	const int linesz = 10 + (16 / g * (2 * g + 1)) + 1 + 16 + 1;
	char line_buf[linesz];
	char * const symbols = line_buf + linesz - 16 - 1;
	char *line = NULL;
	const uint8_t *ch = p;

	fprintf(fp, "\n%s -g%d%s($%p, %d bytes):\n", (desc ? desc : ""), g, (little_endian ? " -little" : " -big"), p, n);
	int i, j = 0, k;
	for (i = 0; i < n; i += g, ch += g) {
		if ((i & 0xf) == 0) {
			memset(line_buf, ' ', sizeof(line_buf));
			line_buf[linesz - 1] = '\0';
			line = line_buf;
			line += sprintf(line, "%08x: ", i);
			j = 0;
		}

		switch (g) {
		case 1: line += sprintf(line, "%02x ", *ch); break;
		case 2: line += sprintf(line, "%04x ", little_endian ? (*(u16*)ch) : htons(*(u16*)ch)); goto __ERASE;
		case 4: line += sprintf(line, "%08x ", little_endian ? (*(u32*)ch) : htonl(*(u32*)ch)); goto __ERASE;
__ERASE:
			if (i + g > n) {
				int e_len = (i + g - n) << 1;
				char *e_pos = line - 1 - (little_endian ? (g << 1) : e_len);
				memset(e_pos, ' ', e_len);
			}
		}
		*line = ' '; //handle nul char added by sprintf
		
		for (k = 0; k < g; k++)
			symbols[j++] = (ch[k]>31 && ch[k]<127) ? ch[k] : '.';

		if (((i + g) & 0xf) == 0)
			fprintf(fp, "%s\n", line_buf);
	}
	if (i & 0xf)
		fprintf(fp, "%s\n", line_buf);
	//printf("\n");
}
