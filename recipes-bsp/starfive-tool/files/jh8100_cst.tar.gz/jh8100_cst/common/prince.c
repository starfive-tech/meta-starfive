#include <stdint.h>
#include <stdio.h>
#include <prince.h>
#include <debug_utils.h>

static uint64_t rc[6] = {0x0000000000000000, 0x13198a2e03707344, 0xa4093822299f31d0, 0x082efa98ec4e6c89, 0x452821e638d01377, 0xbe5466cf34e90c6c};

static uint64_t sbox(uint64_t datai) {
	uint64_t array[16] = {0xB, 0xF, 0x3, 0x2, 0xA, 0xC, 0x9, 0x1, 0x6, 0x7, 0x8, 0x0, 0xE, 0x5, 0xD, 0x4};
	return array[datai & 0xf];
}

static uint64_t inv_sbox(uint64_t datai) {
    uint64_t array[16] = { 0xB, 0x7, 0x3, 0x2, 0xF, 0xD, 0x8, 0x9, 0xA, 0x6, 0x4, 0x0, 0x5, 0xE, 0xC, 0x1 };
    return array[datai & 0xf];
}

static uint64_t s(uint64_t datai) {
	return 
	   ((sbox((datai >> 15 * 4) & 0xf) << 15 * 4) |
		(sbox((datai >> 14 * 4) & 0xf) << 14 * 4) |
		(sbox((datai >> 13 * 4) & 0xf) << 13 * 4) |
		(sbox((datai >> 12 * 4) & 0xf) << 12 * 4) |
		(sbox((datai >> 11 * 4) & 0xf) << 11 * 4) |
		(sbox((datai >> 10 * 4) & 0xf) << 10 * 4) |
		(sbox((datai >> 9 * 4) & 0xf) << 9 * 4) |
		(sbox((datai >> 8 * 4) & 0xf) << 8 * 4) |
		(sbox((datai >> 7 * 4) & 0xf) << 7 * 4) |
		(sbox((datai >> 6 * 4) & 0xf) << 6 * 4) |
		(sbox((datai >> 5 * 4) & 0xf) << 5 * 4) |
		(sbox((datai >> 4 * 4) & 0xf) << 4 * 4) |
		(sbox((datai >> 3 * 4) & 0xf) << 3 * 4) |
		(sbox((datai >> 2 * 4) & 0xf) << 2 * 4) |
		(sbox((datai >> 1 * 4) & 0xf) << 1 * 4) |
		(sbox((datai >> 0 * 4) & 0xf) << 0 * 4));
}

static uint64_t inv_s(uint64_t datai) {
    return
        ((inv_sbox((datai >> 15 * 4) & 0xf) << 15 * 4) |
         (inv_sbox((datai >> 14 * 4) & 0xf) << 14 * 4) |
         (inv_sbox((datai >> 13 * 4) & 0xf) << 13 * 4) |
         (inv_sbox((datai >> 12 * 4) & 0xf) << 12 * 4) |
         (inv_sbox((datai >> 11 * 4) & 0xf) << 11 * 4) |
         (inv_sbox((datai >> 10 * 4) & 0xf) << 10 * 4) |
         (inv_sbox((datai >> 9 * 4) & 0xf) << 9 * 4) |
         (inv_sbox((datai >> 8 * 4) & 0xf) << 8 * 4) |
         (inv_sbox((datai >> 7 * 4) & 0xf) << 7 * 4) |
         (inv_sbox((datai >> 6 * 4) & 0xf) << 6 * 4) |
         (inv_sbox((datai >> 5 * 4) & 0xf) << 5 * 4) |
         (inv_sbox((datai >> 4 * 4) & 0xf) << 4 * 4) |
         (inv_sbox((datai >> 3 * 4) & 0xf) << 3 * 4) |
         (inv_sbox((datai >> 2 * 4) & 0xf) << 2 * 4) |
         (inv_sbox((datai >> 1 * 4) & 0xf) << 1 * 4) |
         (inv_sbox((datai >> 0 * 4) & 0xf) << 0 * 4));
}

static uint64_t sr(uint64_t datai) {
	return (((datai & 0xf000000000000000) << 0 *  4) |
			((datai & 0x00000f0000000000) << 4 *  4) |
			((datai & 0x0000000000f00000) << 8 *  4) |
			((datai & 0x000000000000000f) << 12 * 4) |
			((datai & 0x0000f00000000000) << 0 *  4) |
			((datai & 0x000000000f000000) << 4 *  4) |
			((datai & 0x00000000000000f0) << 8 *  4) |
			((datai & 0x000f000000000000) >> 4 *  4) |
			((datai & 0x00000000f0000000) >> 0 *  4) |
			((datai & 0x0000000000000f00) << 4 *  4) |
			((datai & 0x00f0000000000000) >> 8 *  4) |
			((datai & 0x0000000f00000000) >> 4 *  4) |
			((datai & 0x000000000000f000) >> 0 *  4) |
			((datai & 0x0f00000000000000) >> 12 * 4) |
			((datai & 0x000000f000000000) >> 8 *  4) |
			((datai & 0x00000000000f0000) >> 4 *  4) );
}

static uint64_t inv_sr(uint64_t datai) {
    return 
       (((datai & 0xf000000000000000) >> 0 * 4) |
        ((datai & 0x00000f0000000000) >> 4 * 4) |
        ((datai & 0x0000000000f00000) << 8 * 4) |
        ((datai & 0x000000000000000f) << 4 * 4) |
        ((datai & 0x0000f00000000000) >> 0 * 4) |
        ((datai & 0x000000000f000000) >> 4 * 4) |
        ((datai & 0x00000000000000f0) << 8 * 4) |
        ((datai & 0x000f000000000000) >> 12 * 4) |
        ((datai & 0x00000000f0000000) << 0 * 4) |
        ((datai & 0x0000000000000f00) << 12 * 4) |
        ((datai & 0x00f0000000000000) >> 8 * 4) |
        ((datai & 0x0000000f00000000) << 4 * 4) |
        ((datai & 0x000000000000f000) << 0 * 4) |
        ((datai & 0x0f00000000000000) >> 4 * 4) |
        ((datai & 0x000000f000000000) >> 8 * 4) |
        ((datai & 0x00000000000f0000) << 4 * 4));
}


static uint64_t mp(uint64_t datai) {
	uint64_t result = 0;
	result |= (((datai >> 59) ^ (datai >> 55) ^ (datai >> 51)) & 0x1) << 63;
    result |= (((datai >> 62) ^ (datai >> 54) ^ (datai >> 50)) & 0x1) << 62;
    result |= (((datai >> 61) ^ (datai >> 57) ^ (datai >> 49)) & 0x1) << 61;
    result |= (((datai >> 60) ^ (datai >> 56) ^ (datai >> 52)) & 0x1) << 60;
    result |= (((datai >> 63) ^ (datai >> 59) ^ (datai >> 55)) & 0x1) << 59;
    result |= (((datai >> 58) ^ (datai >> 54) ^ (datai >> 50)) & 0x1) << 58;
    result |= (((datai >> 61) ^ (datai >> 53) ^ (datai >> 49)) & 0x1) << 57;
    result |= (((datai >> 60) ^ (datai >> 56) ^ (datai >> 48)) & 0x1) << 56;
    result |= (((datai >> 63) ^ (datai >> 59) ^ (datai >> 51)) & 0x1) << 55;
    result |= (((datai >> 62) ^ (datai >> 58) ^ (datai >> 54)) & 0x1) << 54;
    result |= (((datai >> 57) ^ (datai >> 53) ^ (datai >> 49)) & 0x1) << 53;
    result |= (((datai >> 60) ^ (datai >> 52) ^ (datai >> 48)) & 0x1) << 52;
    result |= (((datai >> 63) ^ (datai >> 55) ^ (datai >> 51)) & 0x1) << 51;
    result |= (((datai >> 62) ^ (datai >> 58) ^ (datai >> 50)) & 0x1) << 50;
    result |= (((datai >> 61) ^ (datai >> 57) ^ (datai >> 53)) & 0x1) << 49;
    result |= (((datai >> 56) ^ (datai >> 52) ^ (datai >> 48)) & 0x1) << 48;
    result |= (((datai >> 47) ^ (datai >> 43) ^ (datai >> 39)) & 0x1) << 47;
    result |= (((datai >> 42) ^ (datai >> 38) ^ (datai >> 34)) & 0x1) << 46;
    result |= (((datai >> 45) ^ (datai >> 37) ^ (datai >> 33)) & 0x1) << 45;
    result |= (((datai >> 44) ^ (datai >> 40) ^ (datai >> 32)) & 0x1) << 44;
    result |= (((datai >> 47) ^ (datai >> 43) ^ (datai >> 35)) & 0x1) << 43;
    result |= (((datai >> 46) ^ (datai >> 42) ^ (datai >> 38)) & 0x1) << 42;
    result |= (((datai >> 41) ^ (datai >> 37) ^ (datai >> 33)) & 0x1) << 41;
    result |= (((datai >> 44) ^ (datai >> 36) ^ (datai >> 32)) & 0x1) << 40;
    result |= (((datai >> 47) ^ (datai >> 39) ^ (datai >> 35)) & 0x1) << 39;
    result |= (((datai >> 46) ^ (datai >> 42) ^ (datai >> 34)) & 0x1) << 38;
    result |= (((datai >> 45) ^ (datai >> 41) ^ (datai >> 37)) & 0x1) << 37;
    result |= (((datai >> 40) ^ (datai >> 36) ^ (datai >> 32)) & 0x1) << 36;
    result |= (((datai >> 43) ^ (datai >> 39) ^ (datai >> 35)) & 0x1) << 35;
    result |= (((datai >> 46) ^ (datai >> 38) ^ (datai >> 34)) & 0x1) << 34;
    result |= (((datai >> 45) ^ (datai >> 41) ^ (datai >> 33)) & 0x1) << 33;
    result |= (((datai >> 44) ^ (datai >> 40) ^ (datai >> 36)) & 0x1) << 32;
    result |= (((datai >> 31) ^ (datai >> 27) ^ (datai >> 23)) & 0x1) << 31;
    result |= (((datai >> 26) ^ (datai >> 22) ^ (datai >> 18)) & 0x1) << 30;
    result |= (((datai >> 29) ^ (datai >> 21) ^ (datai >> 17)) & 0x1) << 29;
    result |= (((datai >> 28) ^ (datai >> 24) ^ (datai >> 16)) & 0x1) << 28;
    result |= (((datai >> 31) ^ (datai >> 27) ^ (datai >> 19)) & 0x1) << 27;
    result |= (((datai >> 30) ^ (datai >> 26) ^ (datai >> 22)) & 0x1) << 26;
    result |= (((datai >> 25) ^ (datai >> 21) ^ (datai >> 17)) & 0x1) << 25;
    result |= (((datai >> 28) ^ (datai >> 20) ^ (datai >> 16)) & 0x1) << 24;
    result |= (((datai >> 31) ^ (datai >> 23) ^ (datai >> 19)) & 0x1) << 23;
    result |= (((datai >> 30) ^ (datai >> 26) ^ (datai >> 18)) & 0x1) << 22;
    result |= (((datai >> 29) ^ (datai >> 25) ^ (datai >> 21)) & 0x1) << 21;
    result |= (((datai >> 24) ^ (datai >> 20) ^ (datai >> 16)) & 0x1) << 20;
    result |= (((datai >> 27) ^ (datai >> 23) ^ (datai >> 19)) & 0x1) << 19;
    result |= (((datai >> 30) ^ (datai >> 22) ^ (datai >> 18)) & 0x1) << 18;
    result |= (((datai >> 29) ^ (datai >> 25) ^ (datai >> 17)) & 0x1) << 17;
    result |= (((datai >> 28) ^ (datai >> 24) ^ (datai >> 20)) & 0x1) << 16;
    result |= (((datai >> 11) ^ (datai >>  7) ^ (datai >>  3)) & 0x1) << 15;
    result |= (((datai >> 14) ^ (datai >>  6) ^ (datai >>  2)) & 0x1) << 14;
    result |= (((datai >> 13) ^ (datai >>  9) ^ (datai >>  1)) & 0x1) << 13;
    result |= (((datai >> 12) ^ (datai >>  8) ^ (datai >>  4)) & 0x1) << 12;
    result |= (((datai >> 15) ^ (datai >> 11) ^ (datai >>  7)) & 0x1) << 11;
    result |= (((datai >> 10) ^ (datai >>  6) ^ (datai >>  2)) & 0x1) << 10;
    result |= (((datai >> 13) ^ (datai >>  5) ^ (datai >>  1)) & 0x1) <<  9;
    result |= (((datai >> 12) ^ (datai >>  8) ^ (datai >>  0)) & 0x1) <<  8;
    result |= (((datai >> 15) ^ (datai >> 11) ^ (datai >>  3)) & 0x1) <<  7;
    result |= (((datai >> 14) ^ (datai >> 10) ^ (datai >>  6)) & 0x1) <<  6;
    result |= (((datai >>  9) ^ (datai >>  5) ^ (datai >>  1)) & 0x1) <<  5;
    result |= (((datai >> 12) ^ (datai >>  4) ^ (datai >>  0)) & 0x1) <<  4;
    result |= (((datai >> 15) ^ (datai >>  7) ^ (datai >>  3)) & 0x1) <<  3;
    result |= (((datai >> 14) ^ (datai >> 10) ^ (datai >>  2)) & 0x1) <<  2;
    result |= (((datai >> 13) ^ (datai >>  9) ^ (datai >>  5)) & 0x1) <<  1;
    result |= (((datai >>  8) ^ (datai >>  4) ^ (datai >>  0)) & 0x1) <<  0;

	return result;
}

static uint64_t m(uint64_t datai) {
    return sr(mp(datai));
}

static uint64_t inv_m(uint64_t datai) {
    return mp(inv_sr(datai));
}

uint64_t prince(uint64_t datai, const uint64_t *key, uint8_t enc_dec) {
    uint64_t k0, k0p, k1, result, roundconst;
    uint64_t alpha = 0xc0ac29b7c97c50dd;
    k0 = key[0];
    k0p = (((k0 & 0x1) << 63) | (k0 >> 1)) ^ (k0 >> 63);
    k1 = key[1];
    result = (datai ^ k0);
    result = (enc_dec > 0) ? (datai ^ k0p) : (datai ^ k0);

    for (uint8_t i = 0; i < 6; i++) {
        roundconst = (enc_dec > 0) ? (rc[i] ^ alpha) : rc[i];
        if (i == 0)
            //result = result ^ k1 ^ rc[i];
            result = result ^ k1 ^ roundconst;
        else
            //result = m(s(result)) ^ k1 ^ rc[i];
            result = m(s(result)) ^ k1 ^ roundconst;
    }
    result = s(result);
    result = mp(result);
    result = inv_s(result);
    for (uint8_t i = 6; i < 12; i++) {
        roundconst = (enc_dec > 0) ? (rc[11 - i] ^ alpha) : rc[11 - i];
        if (i == 11)
            //result = result ^ k1 ^ rc[11 - i] ^ alpha;
            result = result ^ k1 ^ roundconst ^ alpha;
        else
            //result = inv_s(inv_m(result ^ k1 ^ rc[11 - i] ^ alpha));
            result = inv_s(inv_m(result ^ k1 ^ roundconst ^ alpha));
    }
    
    result = (enc_dec > 0) ? (result ^ k0) : (result ^ k0p);
    return result;
}

static uint32_t prince_wrapper(uint32_t datai, const uint64_t *key, uint64_t addr) {
    uint64_t datao_tmp;
    datao_tmp = prince(addr, key, PRINCE_ENC);
    debug_printf("prince enc: addr %08lx, datai %08x -> %016lx\n", addr, datai, datao_tmp);
    return (datao_tmp & 0xffffffff) ^ datai;
}

#include <global.h>

//prince key (Big Endian): 0x6576694672617453cab8e9d89b6998a9
static const uint64_t g_prince_key[2] = {0x5374617246697665, 0xa998699bd8e9b8ca};

int prince_encode_aes256_key(const uint32_t *in, uint32_t *out)
{
    //RTL treat input and output as Little Endian, so we need a convertion
    uint32_t in_le[8] = {
        read32_be(in+7), read32_be(in+6), read32_be(in+5), read32_be(in+4),
        read32_be(in+3), read32_be(in+2), read32_be(in+1), read32_be(in+0),
    };
    uint32_t out_le[8] = {0};
    int i, key_words_num = 8;
    uint64_t otp_key_addr = 6, addr = 0;

    //printf("prince key:\n");
    //dump_bytes_line(stdout, g_prince_key, sizeof(g_prince_key), NULL);
    for (i = 0; i < key_words_num; i++) {
        addr = otp_key_addr + i;
        out_le[i] = prince_wrapper(in_le[i], g_prince_key, addr);
    }
    for (i = 0; i < key_words_num; i++) {
        addr = otp_key_addr + i;
        out[i] = read32_be(out_le + key_words_num - 1 - i);
        debug_printf("word addr %08lx, in %08x, out %08x\n", addr, in_le[i], out_le[i]);
    }
    debug_printf("AES256 key in:\n");
    debug_dump_bytes_line(stdout, in, key_words_num*sizeof(*in), NULL);
    debug_printf("prince encoded AES256 key out:\n");
    debug_dump_bytes_line(stdout, out, key_words_num*sizeof(*out), NULL);
    debug_printf("\n");
    
    return 0;
}

int prince_encode_dbg_key(const uint32_t *in, uint32_t *out, uint32_t uid)
{
    //RTL treat input and output as Little Endian, so we need a convertion
    uint32_t in_le[4] = {
        read32_be(in+3), read32_be(in+2), read32_be(in+1), read32_be(in+0),
    };
    uint32_t out_le[4] = {0};
    int i, key_words_num = 4;
    uint64_t otp_key_addr = 14, addr = 0, addr_xor = 0;

    //printf("prince key:\n");
    //dump_bytes_line(stdout, g_prince_key, sizeof(g_prince_key), NULL);
    for (i = 0; i < key_words_num; i++) {
        addr = otp_key_addr + i;
        addr_xor = addr ^ uid;
        out_le[i] = prince_wrapper(in_le[i], g_prince_key, addr_xor);
    }
    for (i = 0; i < key_words_num; i++) {
        addr = otp_key_addr + i;
        addr_xor = addr ^ uid;
        out[i] = read32_be(out_le + key_words_num - 1 - i);
        debug_printf("word addr %08lx, addr_xor_uid %08lx, in %08x, out %08x\n", addr, addr_xor, in_le[i], out_le[i]);
    }
    debug_printf("chip_uid: 0x%08x\n", uid);
    debug_printf("dbg_key in:\n");
    debug_dump_bytes_line(stdout, in, key_words_num*sizeof(*in), NULL);
    debug_printf("prince encoded dbg_key out:\n");
    debug_dump_bytes_line(stdout, out, key_words_num*sizeof(*out), NULL);
    debug_printf("\n");

    return 0;
}

#if 0
int main() {
    uint64_t plaintext, ciphertext;
    uint64_t key[2];
    uint8_t enc_dec;

    //---------------------------------------- Encryption testcase0 --------------------------------------------
    plaintext = 0x0;
    key[0] = 0x0;
    key[1] = 0x0;
    enc_dec = 0;
    ciphertext = prince(plaintext, key, enc_dec);
    if (ciphertext != 0x818665aa0d02dfda) {
        printf("Encryption Fail:\n");
        printf("plaintext = %#llx\n", plaintext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected ciphertext = %#llx, actual ciphertext = %#llx\n\n", 0x818665aa0d02dfda, ciphertext);
    }

    //---------------------------------------- Encryption testcase1 --------------------------------------------
    plaintext = 0xffffffffffffffff;
    key[0] = 0x0;
    key[1] = 0x0;
    enc_dec = 0;
    ciphertext = prince(plaintext, key, enc_dec);
    if (ciphertext != 0x604ae6ca03c20ada) {
        printf("Encryption Fail:\n");
        printf("plaintext = %#llx\n", plaintext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected ciphertext = %#llx, actual ciphertext = %#llx\n\n", 0x604ae6ca03c20ada, ciphertext);
    }
    
    //---------------------------------------- Encryption testcase2 --------------------------------------------
    plaintext = 0x0;
    key[0] = 0xffffffffffffffff;
    key[1] = 0x0;
    enc_dec = 0;
    ciphertext = prince(plaintext, key, enc_dec);
    if (ciphertext != 0x9fb51935fc3df524) {
        printf("Encryption Fail:\n");
        printf("plaintext = %#llx\n", plaintext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected ciphertext = %#llx, actual ciphertext = %#llx\n\n", 0x9fb51935fc3df524, ciphertext);
    }

    //---------------------------------------- Encryption testcase3 --------------------------------------------
    plaintext = 0x0;
    key[0] = 0x0;
    key[1] = 0xffffffffffffffff;
    enc_dec = 0;
    ciphertext = prince(plaintext, key, enc_dec);
    if (ciphertext != 0x78a54cbe737bb7ef) {
        printf("Encryption Fail:\n");
        printf("plaintext = %#llx\n", plaintext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected ciphertext = %#llx, actual ciphertext = %#llx\n\n", 0x78a54cbe737bb7ef, ciphertext);
    }

    //---------------------------------------- Encryption testcase4 --------------------------------------------
    plaintext = 0x0123456789abcdef;
    key[0] = 0x0;
    key[1] = 0xfedcba9876543210;
    enc_dec = 0;
    ciphertext = prince(plaintext, key, enc_dec);
    if (ciphertext != 0xae25ad3ca8fa9ccf) {
        printf("Encryption Fail:\n");
        printf("plaintext = %#llx\n", plaintext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected ciphertext = %#llx, actual ciphertext = %#llx\n\n", 0xae25ad3ca8fa9ccf, ciphertext);
    }


    
    //---------------------------------------- Decryption testcase0 --------------------------------------------
    ciphertext = 0x818665aa0d02dfda;
    key[0] = 0x0;
    key[1] = 0x0;
    enc_dec = 1;
    plaintext = prince(ciphertext, key, enc_dec);
    if (plaintext != 0x0) {
        printf("Decryption Fail:\n");
        printf("ciphertext = %#llx\n", ciphertext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected plaintext = %#016llx, actual plaintext = %#llx\n", 0x0llu, plaintext);
    }
    
    //---------------------------------------- Decryption testcase1 --------------------------------------------
    ciphertext = 0x604ae6ca03c20ada;
    key[0] = 0x0;
    key[1] = 0x0;
    enc_dec = 1;
    plaintext = prince(ciphertext, key, enc_dec);
    if (plaintext != 0xffffffffffffffff) {
        printf("Decryption Fail:\n");
        printf("ciphertext = %#llx\n", ciphertext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected plaintext = %#llx, actual plaintext = %#llx\n", 0xffffffffffffffff, plaintext);
    }

    //---------------------------------------- Decryption testcase2 --------------------------------------------
    ciphertext = 0x9fb51935fc3df524;
    key[0] = 0xffffffffffffffff;
    key[1] = 0x0;
    enc_dec = 1;
    plaintext = prince(ciphertext, key, enc_dec);
    if (plaintext != 0x0) {
        printf("Decryption Fail:\n");
        printf("ciphertext = %#llx\n", ciphertext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected plaintext = %#016llx, actual plaintext = %#llx\n", 0x0llu, plaintext);
    }

    //---------------------------------------- Decryption testcase3 --------------------------------------------
    ciphertext = 0x78a54cbe737bb7ef;
    key[0] = 0x0;
    key[1] = 0xffffffffffffffff;
    enc_dec = 1;
    plaintext = prince(ciphertext, key, enc_dec);
    if (plaintext != 0x0) {
        printf("Decryption Fail:\n");
        printf("ciphertext = %#llx\n", ciphertext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected plaintext = %#llx, actual plaintext = %#llx\n", 0x0llu, plaintext);
    }

    //---------------------------------------- Decryption testcase4 --------------------------------------------
    ciphertext = 0xae25ad3ca8fa9ccf;
    key[0] = 0x0;
    key[1] = 0xfedcba9876543210;
    enc_dec = 1;
    plaintext = prince(ciphertext, key, enc_dec);
    if (plaintext != 0x0123456789abcdef) {
        printf("Decryption Fail:\n");
        printf("ciphertext = %#llx\n", ciphertext);
        printf("key[0] = %#llx\n", key[0]);
        printf("key[1] = %#llx\n", key[1]);
        printf("Expected plaintext = %#llx, actual plaintext = %#llx\n", 0x0123456789abcdef, plaintext);
    }
    

	while (1);
	return 0;
}
#endif
