/**
 ******************************************************************************
 * @copyright Copyright (c) 2020, StarFive Technology Co.,Ltd. All rights reserved.
 * 
 * @file aes256.c
 * @author StarFive FW Team
 * @brief 
 ******************************************************************************
 */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <global.h>
#include <debug_utils.h>

//------------------------------------------------------
//AES256-CBC APIs begin

int aes256_cbc_crypt(
        int encrypt,
        int pad,
        const uint8_t *key,
        const uint8_t *iv,
        uint8_t *in,
        int inlen,
        uint8_t *out,
        int outlen
    )
{
    unsigned blocksize;
    int out_len, total_out_len = 0;
    EVP_CIPHER_CTX *ctx;
    ctx = EVP_CIPHER_CTX_new();

    EVP_CipherInit(ctx, EVP_aes_256_cbc(), key, iv, !!encrypt);
    EVP_CIPHER_CTX_set_padding(ctx, pad ? EVP_PADDING_PKCS7 : 0);
    blocksize = EVP_CIPHER_CTX_block_size(ctx);
    if (encrypt && outlen < ((inlen + blocksize - 1) & ~(blocksize - 1))) {
        printf("small out buff, need >= %d bytes (blocksize %d)\n", inlen + blocksize, blocksize);
        return -EINVAL;
    }

    // Cipher data of in_buff
    EVP_CipherUpdate(ctx, out, &out_len, in, inlen);
    out += out_len;
    total_out_len += out_len;

    // Now cipher the final block.
    EVP_CipherFinal(ctx, out, &out_len);
    total_out_len += out_len;

    // Free memory
    EVP_CIPHER_CTX_free(ctx);

    printf("\n%s: in_size %d, out_size %d\n", encrypt ? "encrypt" : "decrypt", inlen, total_out_len);

    return total_out_len;
}

int aes256_cbc_crypt_file(
        int encrypt,
        const uint8_t *key,
        const uint8_t *iv,
        const char *infile,
        const char *outfile
    )
{
    FILE *ifp = fopen(infile, "rb");
    if (!ifp) {
        return -EINVAL;
    }
    FILE *ofp = fopen(outfile, "wb");
    if (!ofp) {
        fclose(ifp);
        return -EINVAL;
    }

    const unsigned BUFSIZE=4096;
    unsigned char *read_buf = malloc(BUFSIZE);
    unsigned char *cipher_buf;
    unsigned blocksize;
    int out_len, total_in_len = 0, total_out_len = 0;
    EVP_CIPHER_CTX *ctx;
    ctx = EVP_CIPHER_CTX_new();

    EVP_CipherInit(ctx, EVP_aes_256_cbc(), key, iv, !!encrypt);
    EVP_CIPHER_CTX_set_padding(ctx, EVP_PADDING_PKCS7);
    blocksize = EVP_CIPHER_CTX_block_size(ctx);
    cipher_buf = malloc(BUFSIZE + blocksize);

    while (1) {
        // Read in data in blocks until EOF. Update the ciphering with each read.
        int numRead = fread(read_buf, sizeof(unsigned char), BUFSIZE, ifp);
        EVP_CipherUpdate(ctx, cipher_buf, &out_len, read_buf, numRead);
        fwrite(cipher_buf, sizeof(unsigned char), out_len, ofp);
        total_out_len += out_len;
        total_in_len += numRead;
        if (numRead < BUFSIZE) { // EOF
            break;
        }
    }

    // Now cipher the final block and write it out.
    EVP_CipherFinal(ctx, cipher_buf, &out_len);
    fwrite(cipher_buf, sizeof(unsigned char), out_len, ofp);
    total_out_len += out_len;

    // Free memory
    free(cipher_buf);
    free(read_buf);
    EVP_CIPHER_CTX_free(ctx);

    // Close file
    fclose(ofp);
    fclose(ifp);

    printf("%s %s, %d bytes -> %s, %d bytes\n", encrypt ? "encrypt" : "decrypt",
        infile, total_in_len, outfile, total_out_len);
    return total_out_len;
}
